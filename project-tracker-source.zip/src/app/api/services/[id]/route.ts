import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  const body = await readBody<{
    name?: string; description?: string; capabilities?: string[]; color?: string; icon?: string;
  }>(req);
  const data: Record<string, unknown> = {};
  if (body?.name?.trim()) data.name = body.name.trim();
  if (body?.description !== undefined) data.description = body.description;
  if (body?.capabilities !== undefined) {
    data.capabilities = JSON.stringify(Array.isArray(body.capabilities) ? body.capabilities.filter(Boolean) : []);
  }
  if (body?.color) data.color = body.color;
  if (body?.icon) data.icon = body.icon;
  if (!Object.keys(data).length) return jsonError("چیزی برای بروزرسانی نیست");
  const updated = await db.service.update({ where: { id }, data });
  return NextResponse.json({ service: updated });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  const count = await db.project.count({ where: { serviceId: id } });
  if (count > 0) {
    return jsonError(`این سرویس ${count} پروژه فعال دارد؛ ابتدا پروژه‌ها را حذف یا منتقل کنید`, 409);
  }
  await db.service.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
