import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

export async function GET() {
  const user = await guard();
  if (isResponse(user)) return user;
  const services = await db.service.findMany({
    orderBy: { order: "asc" },
    include: { _count: { select: { projects: true } } },
  });
  return NextResponse.json({ services });
}

export async function POST(req: NextRequest) {
  const user = await guard();
  if (isResponse(user)) return user;
  const body = await readBody<{
    name?: string; description?: string; capabilities?: string[]; color?: string; icon?: string;
  }>(req);
  if (!body?.name?.trim()) return jsonError("نام سرویس الزامی است");
  const maxOrder = await db.service.aggregate({ _max: { order: true } });
  const created = await db.service.create({
    data: {
      name: body.name.trim(),
      description: body.description ?? "",
      capabilities: JSON.stringify(Array.isArray(body.capabilities) ? body.capabilities.filter(Boolean) : []),
      color: body.color || "#0d9488",
      icon: body.icon || "Layers",
      order: (maxOrder._max.order ?? 0) + 1,
    },
  });
  return NextResponse.json({ service: created });
}
