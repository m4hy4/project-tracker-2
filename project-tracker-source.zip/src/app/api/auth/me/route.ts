import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/session";
import { ensureSeed } from "@/lib/seed";

export async function GET() {
  try {
    await ensureSeed();
    const user = await getSessionUser();
    return NextResponse.json({ user });
  } catch (e) {
    return NextResponse.json({ user: null, error: String(e) }, { status: 500 });
  }
}
