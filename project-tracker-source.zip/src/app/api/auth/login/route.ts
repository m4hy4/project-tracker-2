import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { COOKIE_NAME, hashPassword, signToken } from "@/lib/session";
import { ensureSeed } from "@/lib/seed";
import { readBody } from "@/lib/api-helpers";

export async function POST(req: NextRequest) {
  try {
    await ensureSeed();
    const body = await readBody<{ username?: string; password?: string }>(req);
    if (!body?.username || !body?.password) {
      return NextResponse.json({ error: "نام کاربری و پسورد الزامی است" }, { status: 400 });
    }
    const user = await db.user.findUnique({ where: { username: body.username.trim() } });
    if (!user || user.password !== hashPassword(body.password)) {
      return NextResponse.json({ error: "نام کاربری یا پسورد اشتباه است" }, { status: 401 });
    }
    const res = NextResponse.json({
      user: { id: user.id, username: user.username, name: user.name, role: user.role },
    });
    res.cookies.set(COOKIE_NAME, signToken(user.id), {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
    });
    return res;
  } catch (e) {
    return NextResponse.json({ error: "خطا در ورود: " + String(e) }, { status: 500 });
  }
}
