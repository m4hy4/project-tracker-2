import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, readBody } from "@/lib/api-helpers";

export async function GET() {
  const user = await guard();
  if (isResponse(user)) return user;
  const rows = await db.setting.findMany();
  const settings: Record<string, string> = {};
  for (const r of rows) settings[r.key] = r.value;
  if (!settings["warningDays"]) settings["warningDays"] = "3";
  return NextResponse.json({ settings });
}

export async function PUT(req: NextRequest) {
  const user = await guard();
  if (isResponse(user)) return user;
  const body = await readBody<{ warningDays?: number }>(req);
  if (body?.warningDays !== undefined) {
    const v = String(Math.max(0, Math.min(60, Math.round(body.warningDays))));
    await db.setting.upsert({ where: { key: "warningDays" }, update: { value: v }, create: { key: "warningDays", value: v } });
  }
  const rows = await db.setting.findMany();
  const settings: Record<string, string> = {};
  for (const r of rows) settings[r.key] = r.value;
  return NextResponse.json({ settings });
}
