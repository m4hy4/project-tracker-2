import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse } from "@/lib/api-helpers";

type Ctx = { params: Promise<{ id: string }> };

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  const comment = await db.comment.findUnique({ where: { id } });
  if (!comment) return NextResponse.json({ ok: true });
  if (user.role !== "admin" && comment.authorName !== user.name) {
    return NextResponse.json({ error: "فقط نویسنده یا مدیر می‌تواند کامنت را حذف کند" }, { status: 403 });
  }
  await db.comment.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
