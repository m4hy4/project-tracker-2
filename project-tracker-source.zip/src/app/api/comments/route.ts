import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

export async function POST(req: NextRequest) {
  const user = await guard();
  if (isResponse(user)) return user;
  const body = await readBody<{ taskId?: string | null; projectId?: string | null; body?: string }>(req);
  if (!body?.body?.trim()) return jsonError("متن کامنت خالی است");
  if (!body?.taskId && !body?.projectId) return jsonError("کامنت باید به پروژه یا کار متصل شود");
  const created = await db.comment.create({
    data: {
      taskId: body.taskId || null,
      projectId: body.taskId ? null : body.projectId || null,
      authorName: user.name,
      body: body.body.trim(),
    },
  });
  return NextResponse.json({ comment: created });
}
