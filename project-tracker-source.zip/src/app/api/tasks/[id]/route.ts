import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  const body = await readBody<{
    title?: string; description?: string; status?: string; progress?: number;
    startDate?: string | null; dueDate?: string | null; assignee?: string; order?: number;
  }>(req);
  const data: Record<string, unknown> = {};
  if (body?.title?.trim()) data.title = body.title.trim();
  if (body?.description !== undefined) data.description = body.description;
  if (body?.status) {
    data.status = body.status;
    // همگام‌سازی پیشرفت با وضعیت
    if (body.status === "done") data.progress = 100;
    else if (body.status === "todo") data.progress = 0;
    else if (body.status === "in_progress" && (body.progress ?? 0) === 0) data.progress = 10;
  }
  if (body?.progress !== undefined) data.progress = Math.max(0, Math.min(100, Math.round(body.progress)));
  if (body?.startDate !== undefined) data.startDate = body.startDate || null;
  if (body?.dueDate !== undefined) data.dueDate = body.dueDate || null;
  if (body?.assignee !== undefined) data.assignee = body.assignee;
  if (body?.order !== undefined) data.order = body.order;
  if (!Object.keys(data).length) return jsonError("چیزی برای بروزرسانی نیست");
  const updated = await db.task.update({ where: { id }, data });
  return NextResponse.json({ task: updated });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  await db.task.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
