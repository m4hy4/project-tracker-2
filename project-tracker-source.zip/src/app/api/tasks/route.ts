import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

export async function POST(req: NextRequest) {
  const user = await guard();
  if (isResponse(user)) return user;
  const body = await readBody<{
    projectId?: string; title?: string; description?: string; startDate?: string;
    dueDate?: string; assignee?: string; status?: string;
  }>(req);
  if (!body?.projectId) return jsonError("شناسه پروژه الزامی است");
  if (!body?.title?.trim()) return jsonError("عنوان کار الزامی است");
  const project = await db.project.findUnique({ where: { id: body.projectId } });
  if (!project) return jsonError("پروژه یافت نشد", 404);
  const maxOrder = await db.task.aggregate({ _max: { order: true }, where: { projectId: body.projectId } });
  const created = await db.task.create({
    data: {
      projectId: body.projectId,
      title: body.title.trim(),
      description: body.description ?? "",
      status: body.status || "todo",
      progress: 0,
      startDate: body.startDate || null,
      dueDate: body.dueDate || null,
      assignee: body.assignee ?? "",
      order: (maxOrder._max.order ?? 0) + 1,
    },
  });
  return NextResponse.json({ task: created });
}
