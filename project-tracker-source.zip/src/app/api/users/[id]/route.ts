import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";
import { hashPassword } from "@/lib/session";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  const user = await guard(true);
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  const body = await readBody<{ name?: string; password?: string; role?: string }>(req);
  const data: Record<string, string> = {};
  if (body?.name?.trim()) data.name = body.name.trim();
  if (body?.password) data.password = hashPassword(body.password);
  if (body?.role) data.role = body.role === "admin" ? "admin" : "member";
  if (!Object.keys(data).length) return jsonError("چیزی برای بروزرسانی نیست");
  const updated = await db.user.update({
    where: { id },
    data,
    select: { id: true, username: true, name: true, role: true },
  });
  return NextResponse.json({ user: updated });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await guard(true);
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  if (id === user.id) return jsonError("حذف کاربر خودِ شما مجاز نیست");
  await db.user.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
