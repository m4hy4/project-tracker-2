import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";
import { hashPassword } from "@/lib/session";

export async function GET() {
  const user = await guard(true);
  if (isResponse(user)) return user;
  const users = await db.user.findMany({
    select: { id: true, username: true, name: true, role: true, createdAt: true },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json({ users });
}

export async function POST(req: NextRequest) {
  const user = await guard(true);
  if (isResponse(user)) return user;
  const body = await readBody<{ username?: string; name?: string; password?: string; role?: string }>(req);
  if (!body?.username?.trim() || !body?.name?.trim() || !body?.password) {
    return jsonError("نام نمایشی، نام کاربری و پسورد الزامی است");
  }
  const exists = await db.user.findUnique({ where: { username: body.username.trim() } });
  if (exists) return jsonError("این نام کاربری قبلاً ثبت شده است");
  const created = await db.user.create({
    data: {
      username: body.username.trim(),
      name: body.name.trim(),
      password: hashPassword(body.password),
      role: body.role === "admin" ? "admin" : "member",
    },
    select: { id: true, username: true, name: true, role: true },
  });
  return NextResponse.json({ user: created });
}
