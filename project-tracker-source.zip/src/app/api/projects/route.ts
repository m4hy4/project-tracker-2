import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

/** همه پروژه‌ها با تسک‌ها، مشکلات و کامنت‌ها (برای محاسبه چراغ‌ها سمت کلاینت) */
export async function GET() {
  const user = await guard();
  if (isResponse(user)) return user;
  const projects = await db.project.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      service: true,
      tasks: { orderBy: { order: "asc" }, include: { comments: true, issues: true } },
      issues: { orderBy: { occurredAt: "desc" } },
      comments: { orderBy: { createdAt: "asc" } },
    },
  });
  return NextResponse.json({ projects });
}

export async function POST(req: NextRequest) {
  const user = await guard();
  if (isResponse(user)) return user;
  const body = await readBody<{
    name?: string; serviceId?: string; description?: string; location?: string;
    ownerName?: string; startDate?: string; dueDate?: string;
  }>(req);
  if (!body?.name?.trim()) return jsonError("نام پروژه الزامی است");
  if (!body?.serviceId) return jsonError("انتخاب سرویس الزامی است");
  const service = await db.service.findUnique({ where: { id: body.serviceId } });
  if (!service) return jsonError("سرویس یافت نشد", 404);
  const created = await db.project.create({
    data: {
      name: body.name.trim(),
      serviceId: body.serviceId,
      description: body.description ?? "",
      location: body.location ?? "",
      ownerName: body.ownerName ?? user.name,
      status: "active",
      startDate: body.startDate || null,
      dueDate: body.dueDate || null,
    },
    include: { service: true, tasks: true, issues: true, comments: true },
  });
  return NextResponse.json({ project: created });
}
