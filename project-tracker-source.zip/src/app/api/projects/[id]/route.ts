import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  const project = await db.project.findUnique({
    where: { id },
    include: {
      service: true,
      tasks: { orderBy: { order: "asc" }, include: { comments: true, issues: true } },
      issues: { orderBy: { occurredAt: "desc" } },
      comments: { orderBy: { createdAt: "asc" } },
    },
  });
  if (!project) return jsonError("پروژه یافت نشد", 404);
  return NextResponse.json({ project });
}

export async function PUT(req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  const body = await readBody<{
    name?: string; description?: string; location?: string; ownerName?: string;
    status?: string; startDate?: string | null; dueDate?: string | null; serviceId?: string;
  }>(req);
  const data: Record<string, unknown> = {};
  if (body?.name?.trim()) data.name = body.name.trim();
  if (body?.description !== undefined) data.description = body.description;
  if (body?.location !== undefined) data.location = body.location;
  if (body?.ownerName !== undefined) data.ownerName = body.ownerName;
  if (body?.status) data.status = body.status;
  if (body?.startDate !== undefined) data.startDate = body.startDate || null;
  if (body?.dueDate !== undefined) data.dueDate = body.dueDate || null;
  if (body?.serviceId) data.serviceId = body.serviceId;
  if (!Object.keys(data).length) return jsonError("چیزی برای بروزرسانی نیست");
  const updated = await db.project.update({
    where: { id },
    data,
    include: {
      service: true,
      tasks: { orderBy: { order: "asc" }, include: { comments: true, issues: true } },
      issues: { orderBy: { occurredAt: "desc" } },
      comments: { orderBy: { createdAt: "asc" } },
    },
  });
  return NextResponse.json({ project: updated });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  await db.project.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
