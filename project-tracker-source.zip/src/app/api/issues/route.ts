import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

export async function POST(req: NextRequest) {
  const user = await guard();
  if (isResponse(user)) return user;
  const body = await readBody<{
    projectId?: string; taskId?: string | null; title?: string; description?: string;
    occurredAt?: string; estimatedResolveAt?: string;
  }>(req);
  if (!body?.title?.trim()) return jsonError("عنوان مشکل الزامی است");
  if (!body?.occurredAt) return jsonError("تاریخ بروز مشکل الزامی است");
  if (!body?.estimatedResolveAt) return jsonError("پیش‌بینی رفع مشکل الزامی است");
  if (body.estimatedResolveAt < body.occurredAt) {
    return jsonError("تاریخ پیش‌بینی رفع باید بعد از تاریخ بروز مشکل باشد");
  }
  if (!body?.projectId && !body?.taskId) return jsonError("مشکل باید به پروژه یا کار متصل شود");

  let projectId = body.projectId ?? null;
  if (body.taskId) {
    const task = await db.task.findUnique({ where: { id: body.taskId } });
    if (!task) return jsonError("کار یافت نشد", 404);
    projectId = task.projectId;
  }
  if (!projectId) return jsonError("پروژه یافت نشد", 404);

  const created = await db.issue.create({
    data: {
      projectId,
      taskId: body.taskId || null,
      title: body.title.trim(),
      description: body.description ?? "",
      occurredAt: body.occurredAt,
      estimatedResolveAt: body.estimatedResolveAt,
      createdBy: user.name,
    },
  });
  return NextResponse.json({ issue: created });
}
