import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { guard, isResponse, jsonError, readBody } from "@/lib/api-helpers";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  const body = await readBody<{
    title?: string; description?: string; occurredAt?: string;
    estimatedResolveAt?: string; resolved?: boolean; unresolved?: boolean;
  }>(req);
  const data: Record<string, unknown> = {};
  if (body?.title?.trim()) data.title = body.title.trim();
  if (body?.description !== undefined) data.description = body.description;
  if (body?.occurredAt) data.occurredAt = body.occurredAt;
  if (body?.estimatedResolveAt) data.estimatedResolveAt = body.estimatedResolveAt;
  if (body?.resolved) data.resolvedAt = new Date().toISOString().slice(0, 10);
  if (body?.unresolved) data.resolvedAt = null;
  if (!Object.keys(data).length) return jsonError("چیزی برای بروزرسانی نیست");
  const updated = await db.issue.update({ where: { id }, data });
  return NextResponse.json({ issue: updated });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await guard();
  if (isResponse(user)) return user;
  const { id } = await ctx.params;
  await db.issue.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
