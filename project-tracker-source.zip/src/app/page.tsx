"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { api, normalizeProjects, normalizeServices } from "@/components/tracker/api";
import { LoginPage } from "@/components/tracker/LoginPage";
import { Header, TopTab } from "@/components/tracker/Header";
import { DashboardView } from "@/components/tracker/DashboardView";
import { ProjectView } from "@/components/tracker/ProjectView";
import { SettingsView } from "@/components/tracker/SettingsView";
import { ProjectDialog, ServiceDialog } from "@/components/tracker/dialogs";
import { PrintingOverlay } from "@/components/tracker/ExportMenu";
import { ProjectReport } from "@/components/tracker/ProjectReport";
import { ProjectT, Service, Settings, User } from "@/components/tracker/types";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { AlertTriangle, RefreshCw } from "lucide-react";

export default function Home() {
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [booting, setBooting] = useState(true);
  const [fatal, setFatal] = useState<string | null>(null);

  const [projects, setProjects] = useState<ProjectT[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [settings, setSettings] = useState<Settings>({ warningDays: 3 });

  const [tab, setTab] = useState<TopTab>("dashboard");
  const [openProjectId, setOpenProjectId] = useState<string | null>(null);

  const [svcDialog, setSvcDialog] = useState<{ open: boolean; initial: Service | null }>({ open: false, initial: null });
  const [projDialog, setProjDialog] = useState<{ open: boolean; initial: ProjectT | null }>({ open: false, initial: null });
  const [printProjectId, setPrintProjectId] = useState<string | null>(null);

  const loadProjects = useCallback(async () => {
    try {
      const { projects: raw } = await api.projects();
      setProjects(normalizeProjects(raw));
    } catch (e) {
      toast({ title: "خطا در دریافت پروژه‌ها", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }, [toast]);

  const loadServices = useCallback(async () => {
    try {
      const { services: raw } = await api.services();
      setServices(normalizeServices(raw));
    } catch (e) {
      toast({ title: "خطا در دریافت سرویس‌ها", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }, [toast]);

  const loadSettings = useCallback(async () => {
    try {
      const { settings: s } = await api.settings();
      setSettings({ warningDays: Number(s.warningDays ?? 3) });
    } catch {
      /* پیش‌فرض می‌ماند */
    }
  }, []);

  const loadUsers = useCallback(async () => {
    try {
      const { users: u } = await api.users();
      setUsers(u);
    } catch {
      setUsers([]);
    }
  }, []);

  const boot = useCallback(async () => {
    setBooting(true);
    try {
      const { user: me } = await api.me();
      if (me) {
        setUser(me);
        await Promise.all([loadProjects(), loadServices(), loadSettings(), loadUsers()]);
      }
    } catch (e) {
      setFatal(e instanceof Error ? e.message : String(e));
    } finally {
      setBooting(false);
    }
  }, [loadProjects, loadServices, loadSettings, loadUsers]);

  useEffect(() => {
    boot();
  }, [boot]);

  const refreshAll = useCallback(async () => {
    await Promise.all([loadProjects(), loadServices(), loadSettings()]);
    loadUsers();
  }, [loadProjects, loadServices, loadSettings, loadUsers]);

  async function handleLogin(u: User) {
    setUser(u);
    await refreshAll();
  }

  async function handleLogout() {
    try {
      await api.logout();
    } finally {
      setUser(null);
      setOpenProjectId(null);
      setTab("dashboard");
    }
  }

  const openProject = useMemo(
    () => (openProjectId ? projects.find((p) => p.id === openProjectId) ?? null : null),
    [projects, openProjectId]
  );
  const printProject = useMemo(
    () => (printProjectId ? projects.find((p) => p.id === printProjectId) ?? null : null),
    [projects, printProjectId]
  );

  function doPrint(id: string) {
    setPrintProjectId(id);
    setTimeout(() => {
      window.print();
      window.addEventListener("afterprint", () => setPrintProjectId(null), { once: true });
      // ضمانت پاک شدن حالت چاپ اگر رویداد afterprint صادر نشود
      setTimeout(() => setPrintProjectId((prev) => (prev === id ? null : prev)), 30000);
    }, 300);
  }

  if (booting) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-950">
        <div className="text-center space-y-3">
          <img src="/irancell-logo.png" alt="ایرانسل" className="h-16 mx-auto object-contain" />
          <div className="animate-spin h-6 w-6 border-3 border-teal-500 border-t-transparent rounded-full mx-auto" />
        </div>
      </div>
    );
  }

  if (fatal) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="rounded-xl border bg-red-50 border-red-200 max-w-md p-6 text-center space-y-3">
          <AlertTriangle className="h-8 w-8 text-red-600 mx-auto" />
          <p className="font-bold">خطا در راه‌اندازی سامانه</p>
          <p className="text-xs text-red-700 font-mono break-all" dir="ltr">{fatal}</p>
          <Button onClick={boot} className="gap-2"><RefreshCw className="h-4 w-4" /> تلاش مجدد</Button>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <>
      <div className="min-h-screen flex flex-col">
        <Header user={user} tab={tab} onTab={(t) => { setTab(t); }} onLogout={handleLogout} />

        <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-6">
          {tab === "settings" ? (
            <SettingsView
              settings={settings}
              onSavedSettings={loadSettings}
              user={user}
              users={users}
              onUsersChanged={loadUsers}
            />
          ) : openProject ? (
            <ProjectView
              project={openProject}
              settings={settings}
              user={user}
              users={users}
              onBack={() => setOpenProjectId(null)}
              onChanged={loadProjects}
              onEditProject={() => setProjDialog({ open: true, initial: openProject })}
              onPrint={() => doPrint(openProject.id)}
            />
          ) : (
            <DashboardView
              projects={projects}
              services={services}
              settings={settings}
              onOpenProject={(id) => { setOpenProjectId(id); setTab("dashboard"); }}
              onNewProject={() => setProjDialog({ open: true, initial: null })}
              onNewService={() => setSvcDialog({ open: true, initial: null })}
              onEditProject={(p) => setProjDialog({ open: true, initial: p })}
              onEditService={(s) => setSvcDialog({ open: true, initial: s })}
              onDeleteProject={async (p) => {
                try {
                  await api.deleteProject(p.id);
                  toast({ title: "پروژه حذف شد", description: p.name });
                  await refreshAll();
                } catch (e) {
                  toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
                }
              }}
            />
          )}
        </main>

        <footer className="mt-auto bg-neutral-950 text-white/50 text-[11px] py-3 text-center">
          سامانه ردیابی پروژه‌ها — ساخت تیم داخلی · تاریخ‌ها شمسی · چراغ وضعیت: سبز / زرد ({settings.warningDays} روز مانده) / قرمز
        </footer>
      </div>

      {/* دیالوگ‌ها */}
      <ServiceDialog
        open={svcDialog.open}
        initial={svcDialog.initial}
        onOpenChange={(v) => setSvcDialog({ open: v, initial: v ? svcDialog.initial : null })}
        onSaved={refreshAll}
      />
      <ProjectDialog
        open={projDialog.open}
        initial={projDialog.initial}
        services={services}
        onOpenChange={(v) => setProjDialog({ open: v, initial: v ? projDialog.initial : null })}
        onSaved={refreshAll}
      />

      {/* گزارش چاپی PDF — بیرون از ساختار اصلی تا با CSS چاپ جایگزین صفحه شود */}
      {printProject && (
        <div className="print-root fixed inset-0 z-50 bg-white overflow-auto">
          <PrintingOverlay />
          <ProjectReport project={printProject} settings={settings} />
        </div>
      )}
    </>
  );
}
