import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "سامانه ردیابی پروژه‌ها | ایرانسل",
  description: "سیستم Tracker پروژه‌های خدمات مخابراتی — پایپ‌لاین، ددلاین، دیلی و خروجی داشبورد",
  icons: { icon: "/irancell-logo.png" },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground min-h-screen flex flex-col">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
