import { NextResponse } from "next/server";
import { getSessionUser, SessionUser } from "./session";

export function jsonError(msg: string, status = 400) {
  return NextResponse.json({ error: msg }, { status });
}

/** بررسی نشست کاربر؛ در صورت نبودِ دسترسی، پاسخ خطا برمی‌گردد */
export async function guard(adminOnly = false): Promise<SessionUser | NextResponse> {
  const user = await getSessionUser();
  if (!user) return jsonError("ابتدا وارد سیستم شوید", 401);
  if (adminOnly && user.role !== "admin") return jsonError("فقط مدیر سیستم مجاز است", 403);
  return user;
}

export function isResponse(x: unknown): x is NextResponse {
  return x instanceof NextResponse;
}

export async function readBody<T>(req: Request): Promise<T | null> {
  try {
    return (await req.json()) as T;
  } catch {
    return null;
  }
}
