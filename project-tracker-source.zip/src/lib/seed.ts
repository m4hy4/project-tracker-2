import { db } from "./db";
import { hashPassword } from "./session";
import { addDays, todayStr } from "./jalali";

function d(offset: number): string {
  return addDays(todayStr(), offset);
}

/** در اولین اجرا دیتای نمونه مخابراتی می‌سازد تا سیستم خالی نباشد */
export async function ensureSeed(): Promise<void> {
  const userCount = await db.user.count();
  if (userCount > 0) return;

  await db.setting.upsert({
    where: { key: "warningDays" },
    update: {},
    create: { key: "warningDays", value: "3" },
  });

  await db.user.createMany({
    data: [
      { username: "admin", name: "مدیر سیستم", password: hashPassword("admin123"), role: "admin" },
      { username: "ali", name: "علی محمدی", password: hashPassword("ali123"), role: "member" },
      { username: "sara", name: "سارا کریمی", password: hashPassword("sara123"), role: "member" },
      { username: "reza", name: "رضا احمدی", password: hashPassword("reza123"), role: "member" },
    ],
  });

  const svcBts = await db.service.create({
    data: {
      name: "نصب و راه‌اندازی سایت BTS",
      description:
        "سرویس احداث و راه‌اندازی کامل سایت‌های مخابراتی شامل آماده‌سازی زمین، نصب ستون و دکل، نصب تجهیزات رادیویی، تست و تحویل به بهره‌برداری. خروجی این سرویس یک سایت فعال با پوشش رادیویی تاییدشده است.",
      capabilities: JSON.stringify([
        "بررسی و انتخاب لوکیشن مناسب",
        "اخذ مجوزهای قانونی (شهرداری/ارتفاعات)",
        "فونداسیون و آماده‌سازی سایت",
        "تأمین و نصب ستون/دکل",
        "نصب سکتور آنتن و تجهیزات رادیو",
        "تست آنتن‌دهی و تحویل به بهره‌برداری",
      ]),
      color: "#0d9488",
      icon: "Antenna",
      order: 1,
    },
  });

  const svcFiber = await db.service.create({
    data: {
      name: "فیبر نوری شهری (FTTH)",
      description:
        "طراحی و اجرای شبکه فیبر نوری شهری از مرکز سوئیچ تا مشترکین؛ شامل نقشه‌کشی مسیر، کانال‌کشی، کابل‌کشی، فیوژن و تست نهایی با OTDR.",
      capabilities: JSON.stringify([
        "نقشه‌کشی و طراحی مسیر",
        "حفر و کانال‌کشی",
        "کابل‌کشی فیبر نوری",
        "اسپلیس و فیوژن",
        "نصب اسپلیتر و توزیع",
        "تست OTDR و تحویل خط",
      ]),
      color: "#7c3aed",
      icon: "Cable",
      order: 2,
    },
  });

  const svcNoc = await db.service.create({
    data: {
      name: "پشتیبانی و نگهداشت شبکه",
      description:
        "خدمات پشتیبانی، مانیتورینگ و نگهداشت پیشگیرانه شبکه‌های مخابراتی با پاسخ‌دهی به حوادث بر اساس اولویت و SLA تعریف‌شده.",
      capabilities: JSON.stringify([
        "مانیتورینگ ۲۴ساعته شبکه",
        "نگهداشت پیشگیرانه دوره‌ای",
        "رفع خرابی اضطراری",
        "گزارش‌دهی دوره‌ای عملکرد",
      ]),
      color: "#ea580c",
      icon: "ShieldCheck",
      order: 3,
    },
  });

  // ---------- پروژه ۱: قرمز با دیلی ۷ روزه (شکستگی ستون) ----------
  const p1 = await db.project.create({
    data: {
      name: "سایت BTS پونک — فاز ۲",
      serviceId: svcBts.id,
      description: "احداث سایت جدید پوشش رادیویی در منطقه پونک به دلیل افت کیفیت شبکه در محدوده.",
      location: "تهران، پونک — بلوار عدل",
      ownerName: "علی محمدی",
      status: "active",
      startDate: d(-25),
      dueDate: d(40),
    },
  });
  const p1tasks = await Promise.all(
    (
      [
        ["انتخاب لوکیشن نهایی و توافق مالک", "done", 100, -25, -20],
        ["اخذ مجوز شهرداری", "done", 100, -20, -12],
        ["اجرای فونداسیون و آماده‌سازی سایت", "done", 100, -12, -8],
        ["تأمین و نصب ستون", "in_progress", 60, -8, 5],
        ["نصب سکتور آنتن", "todo", 0, 10, 14],
        ["کابل‌کشی و تغذیه سایت", "todo", 0, 15, 19],
        ["نصب تجهیزات رادیو", "todo", 0, 20, 24],
        ["تست و آنتن‌دهی نهایی", "todo", 0, 25, 30],
        ["تحویل به بهره‌برداری", "todo", 0, 31, 36],
      ] as [string, string, number, number, number][]
    ).map(([title, status, progress, s, due], i) =>
      db.task.create({
        data: {
          projectId: p1.id, title, status, progress, order: i + 1,
          startDate: d(s), dueDate: d(due),
          assignee: i % 2 === 0 ? "علی محمدی" : "رضا احمدی",
        },
      })
    )
  );
  const poleIssue = await db.issue.create({
    data: {
      taskId: p1tasks[3].id,
      projectId: p1.id,
      title: "شکستگی ستون هنگام حمل",
      description: "در عملیات حمل، ستون دچار شکستگی شد و ستون جایگزین باید از انبار اصفهان تأمین شود.",
      occurredAt: d(-2),
      estimatedResolveAt: d(12),
      createdBy: "علی محمدی",
    },
  });
  await db.comment.createMany({
    data: [
      { taskId: p1tasks[3].id, projectId: p1.id, authorName: "علی محمدی", body: "ستون هنگام بارگیری از جرثقیل سقوط کرد و ترک برداشت. علت: جاده خاکی و لرزش زیاد." },
      { taskId: p1tasks[3].id, projectId: p1.id, authorName: "سارا کریمی", body: "ستون جایگزین درخواست شد؛ پیش‌بینی رفع: ۱۲ روز دیگر. عملیات نصب تا آن زمان متوقف است." },
    ],
  });

  // ---------- پروژه ۲: زرد (نزدیک ددلاین) ----------
  const p2 = await db.project.create({
    data: {
      name: "فیبرکشی منطقه ۶ — مسیر ولیعصر",
      serviceId: svcFiber.id,
      description: "اجرای مسیر فیبر نوری در امتداد خیابان ولیعصر از تقاطع انقلاب تا پارک ساعی.",
      location: "تهران، منطقه ۶ — ولیعصر",
      ownerName: "سارا کریمی",
      status: "active",
      startDate: d(-30),
      dueDate: d(2),
    },
  });
  const p2tasks = await Promise.all(
    (
      [
        ["نقشه‌کشی مسیر و استعلام", "done", 100, -30, -22],
        ["کانال‌کشی قطعه ۱", "done", 100, -22, -14],
        ["کانال‌کشی قطعه ۲", "in_progress", 75, -14, 6],
        ["کابل‌کشی فیبر", "blocked", 30, -10, 9],
        ["فیوژن و اسپلیس", "todo", 0, 10, 14],
        ["تست OTDR", "todo", 0, 15, 18],
      ] as [string, string, number, number, number][]
    ).map(([title, status, progress, s, due], i) =>
      db.task.create({
        data: {
          projectId: p2.id, title, status, progress, order: i + 1,
          startDate: d(s), dueDate: d(due),
          assignee: i % 2 === 0 ? "سارا کریمی" : "رضا احمدی",
        },
      })
    )
  );
  await db.issue.create({
    data: {
      taskId: p2tasks[3].id,
      projectId: p2.id,
      title: "وقفه کانال‌کشی بلدیه",
      description: "شهرداری تا تهیه هماهنگی‌های جدید اجازه ادامه حفر در بخش میانی مسیر را نداده است.",
      occurredAt: d(-3),
      estimatedResolveAt: d(4),
      createdBy: "سارا کریمی",
    },
  });
  await db.comment.createMany({
    data: [
      { taskId: p2tasks[3].id, projectId: p2.id, authorName: "سارا کریمی", body: "تا صدور مجوز جدید بلدیه کار متوقف است؛ جلسه با منطقه ۶ برای فردا گذاشته شد." },
      { projectId: p2.id, authorName: "مدیر سیستم", body: "وضعیت زرد است؛ لطفاً روزانه پیگیری مجوز و اگر تا پایان هفته نشد برنامه جایگزین بدهیم." },
    ],
  });

  // ---------- پروژه ۳: سبز ----------
  const p3 = await db.project.create({
    data: {
      name: "سایت BTS شهرک غرب — فاز ۱",
      serviceId: svcBts.id,
      description: "تکمیل سایت شهرک غرب؛ اکثر مراحل انجام شده و فقط تست نهایی باقی است.",
      location: "تهران، شهرک غرب — فاز ۴",
      ownerName: "رضا احمدی",
      status: "active",
      startDate: d(-45),
      dueDate: d(45),
    },
  });
  await Promise.all(
    (
      [
        ["اخذ مجوز و توافق مالک", "done", 100, -45, -38],
        ["فونداسیون و ستون", "done", 100, -38, -25],
        ["نصب سکتور آنتن", "done", 100, -25, -18],
        ["کابل‌کشی و تغذیه", "done", 100, -18, -10],
        ["نصب تجهیزات رادیو", "done", 100, -10, -4],
        ["تست و آنتن‌دهی نهایی", "in_progress", 40, 0, 20],
      ] as [string, string, number, number, number][]
    ).map(([title, status, progress, s, due], i) =>
      db.task.create({
        data: {
          projectId: p3.id, title, status, progress, order: i + 1,
          startDate: d(s), dueDate: d(due),
          assignee: "رضا احمدی",
        },
      })
    )
  );

  // ---------- پروژه ۴: قرارداد پشتیبانی ----------
  const p4 = await db.project.create({
    data: {
      name: "مانیتورینگ NOC — قرارداد سالانه",
      serviceId: svcNoc.id,
      description: "قرارداد پشتیبانی سالانه مانیتورینگ شبکه؛ گزارش‌دهی ماهانه و نگهداشت پیشگیرانه فصلی.",
      location: "مرکز NOC",
      ownerName: "سارا کریمی",
      status: "active",
      startDate: d(-10),
      dueDate: d(90),
    },
  });
  await Promise.all(
    (
      [
        ["راه‌اندازی داشبورد مانیتورینگ", "done", 100, -10, -2],
        ["گزارش ماه اول عملکرد", "in_progress", 50, 0, 12],
        ["نگهداشت پیشگیرانه فصلی", "todo", 0, 30, 45],
        ["گزارش ماه سوم و جمع‌بندی", "todo", 0, 60, 85],
      ] as [string, string, number, number, number][]
    ).map(([title, status, progress, s, due], i) =>
      db.task.create({
        data: {
          projectId: p4.id, title, status, progress, order: i + 1,
          startDate: d(s), dueDate: d(due),
          assignee: i % 2 === 0 ? "سارا کریمی" : "علی محمدی",
        },
      })
    )
  );

  // ---------- پروژه ۵: تمام‌شده ----------
  const p5 = await db.project.create({
    data: {
      name: "فیبرکشی شهرک اکباتان",
      serviceId: svcFiber.id,
      description: "اجرای کامل فیبر نوری شهرک اکباتان؛ تحویل داده شده و در حال بهره‌برداری.",
      location: "تهران، شهرک اکباتان",
      ownerName: "علی محمدی",
      status: "done",
      startDate: d(-90),
      dueDate: d(-10),
    },
  });
  await Promise.all(
    (
      [
        ["نقشه‌کشی مسیر", "done", 100, -90, -80],
        ["کانال‌کشی", "done", 100, -80, -60],
        ["کابل‌کشی فیبر", "done", 100, -60, -40],
        ["فیوژن و اسپلیس", "done", 100, -40, -25],
        ["تست OTDR و تحویل", "done", 100, -25, -10],
      ] as [string, string, number, number, number][]
    ).map(([title, status, progress, s, due], i) =>
      db.task.create({
        data: {
          projectId: p5.id, title, status, progress, order: i + 1,
          startDate: d(s), dueDate: d(due),
          assignee: "علی محمدی",
        },
      })
    )
  );
  await db.comment.create({
    data: { projectId: p5.id, authorName: "مدیر سیستم", body: "پروژه با موفقیت تحویل مشترکین داده شد و صورت‌جلسه نهایی امضا شد." },
  });
}
