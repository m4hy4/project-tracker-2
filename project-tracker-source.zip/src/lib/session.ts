import crypto from "crypto";
import { cookies } from "next/headers";
import { db } from "./db";

const SECRET = process.env.SESSION_SECRET || "irancell-project-tracker-local-secret";
export const COOKIE_NAME = "pt_session";

export function hashPassword(p: string): string {
  return crypto.createHash("sha256").update(p + "::pt").digest("hex");
}

export function signToken(userId: string): string {
  const sig = crypto.createHmac("sha256", SECRET).update(userId).digest("hex");
  return `${userId}.${sig}`;
}

export function verifyToken(token?: string): string | null {
  if (!token) return null;
  const idx = token.lastIndexOf(".");
  if (idx <= 0) return null;
  const id = token.slice(0, idx);
  const sig = token.slice(idx + 1);
  const expected = crypto.createHmac("sha256", SECRET).update(id).digest("hex");
  return sig === expected ? id : null;
}

export interface SessionUser {
  id: string;
  username: string;
  name: string;
  role: string;
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const id = verifyToken(store.get(COOKIE_NAME)?.value);
  if (!id) return null;
  const user = await db.user.findUnique({ where: { id } });
  if (!user) return null;
  return { id: user.id, username: user.username, name: user.name, role: user.role };
}

export async function requireUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) throw new AuthError("ابتدا وارد سیستم شوید");
  return user;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.role !== "admin") throw new AuthError("فقط مدیر سیستم مجاز به این عملیات است");
  return user;
}

export class AuthError extends Error {}
