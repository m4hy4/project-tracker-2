import { diffDays, todayStr, faNum } from "./jalali";

export type Light = "green" | "yellow" | "red" | "done" | "grey";

export interface IssueLike {
  id: string;
  taskId?: string | null;
  projectId?: string | null;
  title: string;
  description?: string;
  occurredAt: string;
  estimatedResolveAt: string;
  resolvedAt?: string | null;
}

export interface TaskLike {
  id: string;
  title: string;
  status: string; // todo | in_progress | blocked | done
  progress: number;
  startDate?: string | null;
  dueDate?: string | null;
  order: number;
  assignee?: string;
}

export interface TaskComputed {
  light: Light;
  daysLeft: number | null; // مانده تا ددلاین مؤثر (منفی = گذشته)
  delayDays: number; // روز تأخیر محاسبه‌شده با احتساب مشکل
  label: string; // متن زیر چراغ
  effectiveDeadline: string | null; // ددلاین مؤثر (با پیش‌بینی رفع مشکل)
  blockedReason: string | null;
  openIssues: IssueLike[];
}

export const LIGHT_COLORS: Record<Light, string> = {
  green: "#16a34a",
  yellow: "#d97706",
  red: "#dc2626",
  done: "#15803d",
  grey: "#94a3b8",
};

export const LIGHT_LABELS: Record<Light, string> = {
  green: "در مسیر",
  yellow: "هشدار",
  red: "تأخیر",
  done: "انجام شد",
  grey: "بی‌مهلت",
};

/** چراغ وضعیت یک تسک — طبق قانون: سبز = زمان کافی، زرد = نزدیک ددلاین، قرمز = تأخیر */
export function computeTask(
  task: TaskLike,
  allIssues: IssueLike[],
  allComments: { taskId?: string | null; body: string; createdAt?: string }[],
  warningDays: number,
  today: string = todayStr()
): TaskComputed {
  const openIssues = allIssues.filter((i) => i.taskId === task.id && !i.resolvedAt);
  const taskComments = allComments.filter((c) => c.taskId === task.id);
  const lastComment = taskComments.length ? taskComments[taskComments.length - 1].body : null;

  if (task.status === "done") {
    return {
      light: "done",
      daysLeft: null,
      delayDays: 0,
      label: "انجام شده",
      effectiveDeadline: task.dueDate ?? null,
      blockedReason: null,
      openIssues: [],
    };
  }

  // ددلاین مؤثر = حداکثر ددلاین تسک و پیش‌بینی رفع آخرین مشکل باز
  const due = task.dueDate ?? null;
  let predictedMax: string | null = null;
  for (const i of openIssues) {
    if (!predictedMax || i.estimatedResolveAt > predictedMax) predictedMax = i.estimatedResolveAt;
  }
  const effective = [due, predictedMax].filter(Boolean) as string[];
  const effectiveDeadline = effective.length ? effective.reduce((a, b) => (a > b ? a : b)) : null;

  // تأخیر: اگر امروز یا پیش‌بینی رفع از ددلاین اصلی جلوتر است
  let delayDays = 0;
  if (due) {
    const horizon = [today, predictedMax].filter(Boolean).sort().slice(-1)[0];
    delayDays = Math.max(0, diffDays(due, horizon));
  }

  let light: Light = "grey";
  let label = "بدون ددلاین";
  if (effectiveDeadline) {
    const daysLeft = diffDays(today, effectiveDeadline);
    if (daysLeft < 0) {
      light = "red";
      label = `${faNum(-daysLeft)} روز تأخیر`;
    } else if (daysLeft <= warningDays) {
      light = "yellow";
      label = daysLeft === 0 ? "امروز ددلاین!" : `${faNum(daysLeft)} روز مانده`;
    } else {
      light = "green";
      label = `${faNum(daysLeft)} روز مانده`;
    }
  } else if (task.status === "blocked") {
    light = "yellow";
    label = "متوقف — نیاز به بررسی";
  }

  if (delayDays > 0 && light !== "red" && task.status !== "done") {
    light = "red";
    label = `${faNum(delayDays)} روز تأخیر`;
  }

  return {
    light,
    daysLeft: effectiveDeadline ? diffDays(today, effectiveDeadline) : null,
    delayDays,
    label,
    effectiveDeadline,
    blockedReason: task.status === "blocked" ? (lastComment ?? "دلیل توقف ثبت نشده") : null,
    openIssues,
  };
}

export const LIGHT_RANK: Record<Light, number> = { red: 0, yellow: 1, green: 2, grey: 3, done: 4 };

/** چراغ کل پروژه = بدترین وضعیت بین تسک‌ها + ددلاین کل پروژه */
export function computeProject(
  project: { status: string; dueDate?: string | null },
  tasks: TaskLike[],
  issues: IssueLike[],
  comments: { taskId?: string | null; projectId?: string | null; body: string }[],
  warningDays: number,
  today: string = todayStr()
): TaskComputed {
  if (project.status === "done") {
    return {
      light: "done", daysLeft: null, delayDays: 0, label: "پروژه انجام شده",
      effectiveDeadline: project.dueDate ?? null, blockedReason: null, openIssues: [],
    };
  }
  const computedTasks = tasks.map((t) => computeTask(t, issues, comments, warningDays, today));
  let worst: TaskComputed | null = null;
  for (const c of computedTasks) {
    if (!worst || LIGHT_RANK[c.light] < LIGHT_RANK[worst.light]) worst = c;
  }
  // ددلاین کل پروژه
  const openProjectIssues = issues.filter((i) => i.projectId && !i.taskId && !i.resolvedAt);
  let projDeadline = project.dueDate ?? null;
  let projDelay = 0;
  if (projDeadline) {
    let predictedMax: string | null = null;
    for (const i of openProjectIssues) {
      if (!predictedMax || i.estimatedResolveAt > predictedMax) predictedMax = i.estimatedResolveAt;
    }
    const horizon = [today, predictedMax].filter(Boolean).sort().slice(-1)[0];
    projDelay = Math.max(0, diffDays(projDeadline, horizon));
    const daysLeft = diffDays(today, projDeadline);
    if (daysLeft < 0 || projDelay > 0) {
      const cand: TaskComputed = {
        light: "red",
        daysLeft,
        delayDays: projDelay,
        label: `${faNum(Math.max(-daysLeft, projDelay))} روز تأخیر`,
        effectiveDeadline: predictedMax ?? projDeadline,
        blockedReason: null,
        openIssues: openProjectIssues,
      };
      if (!worst || LIGHT_RANK[worst.light] > LIGHT_RANK.red) worst = cand;
    } else if (daysLeft <= warningDays) {
      const cand: TaskComputed = {
        light: "yellow",
        daysLeft,
        delayDays: 0,
        label: daysLeft === 0 ? "امروز ددلاین!" : `${faNum(daysLeft)} روز مانده`,
        effectiveDeadline: projDeadline,
        blockedReason: null,
        openIssues: openProjectIssues,
      };
      if (!worst || LIGHT_RANK[worst.light] > LIGHT_RANK.yellow) worst = cand;
    }
  }
  return (
    worst ?? {
      light: "grey", daysLeft: null, delayDays: 0, label: "بدون ددلاین",
      effectiveDeadline: project.dueDate ?? null, blockedReason: null, openIssues: [],
    }
  );
}

/** وضعیت‌های مجاز تسک */
export const TASK_STATUSES = [
  { value: "todo", label: "شروع نشده", color: "#94a3b8" },
  { value: "in_progress", label: "در حال انجام", color: "#0d9488" },
  { value: "blocked", label: "متوقف", color: "#d97706" },
  { value: "done", label: "انجام شده", color: "#16a34a" },
] as const;

export function statusLabel(s: string): string {
  return TASK_STATUSES.find((x) => x.value === s)?.label ?? s;
}

export const PROJECT_STATUSES = [
  { value: "active", label: "فعال" },
  { value: "paused", label: "متوقف" },
  { value: "done", label: "تمام‌شده" },
  { value: "cancelled", label: "لغوشده" },
] as const;
