import { toJalaali, toGregorian, jalaaliMonthLength } from "jalaali-js";

/** تبدیل عدد به ارقام فارسی */
export function faNum(input: number | string): string {
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  return String(input).replace(/\d/g, (d) => fa[Number(d)]);
}

const J_MONTHS = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

/** دریافت رشته تاریخ YYYY-MM-DD و برگرداندن Date لوکال (ظهر برای جلوگیری از مشکلات تایم‌زون) */
export function parseDateStr(s?: string | null): Date | null {
  if (!s) return null;
  const [y, m, d] = s.split("-").map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d, 12, 0, 0);
}

/** تاریخ امروز به‌صورت YYYY-MM-DD بر اساس ساعت لوکال */
export function todayStr(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function dateToStr(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDays(dateStr: string, n: number): string {
  const d = parseDateStr(dateStr) ?? new Date();
  d.setDate(d.getDate() + n);
  return dateToStr(d);
}

/** اختلاف روز: b - a (مثبت یعنی b بعد از a) */
export function diffDays(a: string, b: string): number {
  const da = parseDateStr(a);
  const db = parseDateStr(b);
  if (!da || !db) return 0;
  return Math.round((db.getTime() - da.getTime()) / 86400000);
}

/** YYYY-MM-DD → ۱۴۰۴/۰۸/۱۷ */
export function formatJalali(s?: string | null): string {
  const d = parseDateStr(s);
  if (!d) return "—";
  const j = toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  const mm = String(j.jm).padStart(2, "0");
  const dd = String(j.jd).padStart(2, "0");
  return faNum(`${j.jy}/${mm}/${dd}`);
}

/** تاریخ کامل با نام ماه: ۱۷ آبان ۱۴۰۴ */
export function formatJalaliLong(s?: string | null): string {
  const d = parseDateStr(s);
  if (!d) return "—";
  const j = toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  return `${faNum(j.jd)} ${J_MONTHS[j.jm - 1]} ${faNum(j.jy)}`;
}

export function jalaliMonthName(m: number): string {
  return J_MONTHS[m - 1] ?? "";
}

export function toJalaliParts(s: string): { jy: number; jm: number; jd: number } {
  const d = parseDateStr(s) ?? new Date();
  return toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

export function fromJalaliParts(jy: number, jm: number, jd: number): string {
  const g = toGregorian(jy, jm, jd);
  return `${g.gy}-${String(g.gm).padStart(2, "0")}-${String(g.gd).padStart(2, "0")}`;
}

export function jalaliMonthLength(jy: number, jm: number): number {
  return jalaaliMonthLength(jy, jm);
}

/** روز هفته به فارسی */
export function weekdayFa(s: string): string {
  const d = parseDateStr(s);
  if (!d) return "";
  const names = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
  return names[d.getDay()];
}
