"use client";

import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Download, FileDown, ImageDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatJalaliLong, todayStr } from "@/lib/jalali";
import { toPng } from "html-to-image";

async function downloadPng(elementId: string, filename: string): Promise<string | null> {
  const node = document.getElementById(elementId);
  if (!node) return "عنصر برای خروجی پیدا نشد";
  try {
    const url = await toPng(node, { backgroundColor: "#ffffff", pixelRatio: 2, cacheBust: true });
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    return null;
  } catch (e) {
    return String(e);
  }
}

/** دکمه خروجی داشبورد: عکس PNG هر بخش + PDF گزارش کامل از طریق چاپ */
export function ExportMenu({
  pngItems,
  onPrint,
}: {
  pngItems: { id: string; label: string; filename: string }[];
  onPrint: () => void;
}) {
  const { toast } = useToast();

  async function run(item: { id: string; label: string; filename: string }) {
    const err = await downloadPng(item.id, item.filename);
    if (err) {
      toast({ title: "خطا در خروجی PNG", description: err, variant: "destructive" });
    } else {
      toast({ title: "PNG ذخیره شد", description: `${item.label} — ${item.filename}` });
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button className="gap-2" variant="default">
          <Download className="h-4 w-4" /> خروجی داشبورد
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-60" dir="rtl">
        <DropdownMenuLabel className="flex items-center gap-1.5 text-xs">
          <ImageDown className="h-3.5 w-3.5" /> خروجی PNG (برای پاورپوینت)
        </DropdownMenuLabel>
        {pngItems.map((item) => (
          <DropdownMenuItem key={item.id} onClick={() => run(item)}>{item.label}</DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={onPrint} className="font-semibold">
          <FileDown className="h-3.5 w-3.5 ml-1.5" /> PDF گزارش ارائه (چاپ)
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

/** لایه پوشش هنگام آماده‌سازی گزارش */
export function PrintingOverlay() {
  return (
    <div className="fixed inset-0 z-50 bg-white flex items-center justify-center no-print">
      <div className="text-center space-y-2">
        <div className="animate-spin h-8 w-8 border-4 border-teal-600 border-t-transparent rounded-full mx-auto" />
        <p className="text-sm font-semibold">در حال آماده‌سازی گزارش...</p>
        <p className="text-xs text-muted-foreground">در پنجره چاپ، گزینه «ذخیره به PDF» را انتخاب کنید</p>
      </div>
    </div>
  );
}

export function reportDate(): string {
  return formatJalaliLong(todayStr());
}
