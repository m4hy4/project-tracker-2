"use client";

import { useEffect, useState } from "react";
import { Settings as SettingsType, User } from "./types";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { api } from "./api";
import { useToast } from "@/hooks/use-toast";
import { faNum } from "@/lib/jalali";
import { BellRing, Info, KeyRound, ShieldCheck, Trash2, UserPlus } from "lucide-react";

export function SettingsView({
  settings,
  onSavedSettings,
  user,
  users,
  onUsersChanged,
}: {
  settings: SettingsType;
  onSavedSettings: () => void;
  user: User;
  users: User[];
  onUsersChanged: () => void;
}) {
  const { toast } = useToast();
  const isAdmin = user.role === "admin";
  const [warningDays, setWarningDays] = useState(String(settings.warningDays));
  const [saving, setSaving] = useState(false);

  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({ name: "", username: "", password: "", role: "member" });
  const [pwTarget, setPwTarget] = useState<User | null>(null);
  const [newPw, setNewPw] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<User | null>(null);

  useEffect(() => setWarningDays(String(settings.warningDays)), [settings.warningDays]);

  async function saveSettings() {
    const v = Number(warningDays);
    if (Number.isNaN(v) || v < 0 || v > 60) {
      toast({ title: "خطا", description: "عدد بین ۰ تا ۶۰ وارد کنید", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api.updateSettings({ warningDays: v });
      toast({ title: "ذخیره شد", description: `چراغ زرد = ${faNum(v)} روز مانده؛ چراغ قرمز = گذشته از ددلاین` });
      onSavedSettings();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function addUser() {
    if (!form.name.trim() || !form.username.trim() || !form.password) {
      toast({ title: "خطا", description: "همه فیلدها الزامی است", variant: "destructive" });
      return;
    }
    try {
      await api.createUser(form);
      setForm({ name: "", username: "", password: "", role: "member" });
      setAddOpen(false);
      toast({ title: "کاربر اضافه شد" });
      onUsersChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  async function resetPassword() {
    if (!pwTarget || !newPw) return;
    try {
      await api.updateUser(pwTarget.id, { password: newPw });
      setPwTarget(null);
      setNewPw("");
      toast({ title: "پسورد عوض شد", description: pwTarget.name });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  async function deleteUser() {
    if (!deleteTarget) return;
    try {
      await api.deleteUser(deleteTarget.id);
      toast({ title: "کاربر حذف شد" });
      onUsersChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
    setDeleteTarget(null);
  }

  return (
    <div className="space-y-5 max-w-3xl">
      {/* آستانه چراغ‌ها */}
      <Card>
        <CardContent className="p-5 space-y-4">
          <h3 className="font-bold text-sm flex items-center gap-2">
            <BellRing className="h-4 w-4 text-amber-600" /> آستانه چراغ وضعیت
          </h3>
          <div className="rounded-md bg-accent px-3 py-2.5 text-xs leading-5 text-accent-foreground flex gap-2">
            <Info className="h-4 w-4 shrink-0 mt-0.5" />
            قانون فعلی: سبز = زمان کافی مانده · زرد = {faNum(settings.warningDays)} روز یا کمتر مانده به ددلاین · قرمز = گذشته از ددلاین یا پیش‌بینی رفع مشکل از ددلاین گذشته است.
          </div>
          <div className="flex items-end gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="warn">روزهای هشدار (زرد) قبل از ددلاین</Label>
              <Input id="warn" type="number" min={0} max={60} value={warningDays} onChange={(e) => setWarningDays(e.target.value)} className="w-32" />
            </div>
            <Button onClick={saveSettings} disabled={saving || Number(warningDays) === settings.warningDays}>
              {saving ? "..." : "ذخیره"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* مدیریت کاربران */}
      <Card>
        <CardContent className="p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-teal-700" /> کاربران تیم
              <span className="text-[10px] bg-muted rounded px-1.5 py-0.5">فقط مدیر</span>
            </h3>
            {isAdmin && (
              <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setAddOpen(true)}>
                <UserPlus className="h-3.5 w-3.5" /> افزودن کاربر
              </Button>
            )}
          </div>
          {!isAdmin && <p className="text-xs text-muted-foreground">مدیریت کاربران فقط برای مدیر سیستم فعال است.</p>}
          {isAdmin && (
            <div className="overflow-x-auto custom-scrollbar">
              <table className="w-full text-sm min-w-100">
                <thead>
                  <tr className="text-xs text-muted-foreground border-b">
                    <th className="p-2 text-right">نام نمایشی</th>
                    <th className="p-2 text-right">نام کاربری</th>
                    <th className="p-2 text-center">نقش</th>
                    <th className="p-2 text-center w-28">عملیات</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.id} className="border-b last:border-0">
                      <td className="p-2 font-semibold">{u.name} {u.id === user.id && <span className="text-[10px] text-teal-700">(شما)</span>}</td>
                      <td className="p-2 font-mono text-xs" dir="ltr">{u.username}</td>
                      <td className="p-2 text-center">{u.role === "admin" ? <span className="text-teal-700 font-bold text-xs">مدیر</span> : <span className="text-xs text-muted-foreground">عضو</span>}</td>
                      <td className="p-2 text-center">
                        <Button variant="ghost" size="icon" className="h-7 w-7" title="تغییر پسورد" onClick={() => { setPwTarget(u); setNewPw(""); }}>
                          <KeyRound className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost" size="icon" className="h-7 w-7 text-destructive" title="حذف کاربر"
                          disabled={u.id === user.id}
                          onClick={() => setDeleteTarget(u)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* دیالوگ افزودن کاربر */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>افزودن کاربر</DialogTitle>
            <DialogDescription>کاربر جدید با نام کاربری و پسورد ساده وارد سیستم می‌شود.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>نام نمایشی *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثال: محمد رضایی" />
            </div>
            <div className="space-y-1">
              <Label>نام کاربری *</Label>
              <Input dir="ltr" className="text-left" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} placeholder="mohammad" />
            </div>
            <div className="space-y-1">
              <Label>پسورد *</Label>
              <Input dir="ltr" className="text-left" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••" />
            </div>
            <div className="space-y-1">
              <Label>نقش</Label>
              <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="member">عضو تیم</SelectItem>
                  <SelectItem value="admin">مدیر</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>انصراف</Button>
            <Button onClick={addUser}>افزودن</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* دیالوگ تغییر پسورد */}
      <Dialog open={!!pwTarget} onOpenChange={(v) => !v && setPwTarget(null)}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>تغییر پسورد — {pwTarget?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-1">
            <Label>پسورد جدید</Label>
            <Input dir="ltr" className="text-left" value={newPw} onChange={(e) => setNewPw(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPwTarget(null)}>انصراف</Button>
            <Button onClick={resetPassword} disabled={!newPw}>ذخیره</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* تایید حذف کاربر */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف کاربر</AlertDialogTitle>
            <AlertDialogDescription>«{deleteTarget?.name}» از تیم حذف می‌شود. مطمئنید؟</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-white hover:bg-destructive/90" onClick={deleteUser}>حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
