"use client";

import { Fragment, useState } from "react";
import { CommentT, IssueT, TaskT } from "./types";
import { computeTask, TASK_STATUSES } from "@/lib/status";
import { faNum, formatJalali, todayStr } from "@/lib/jalali";
import { LightBadge } from "./StatusLight";
import { JalaliDatePicker } from "./JalaliDatePicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import {
  ChevronDown, CalendarDays, MessageSquarePlus, PauseCircle,
  PlusCircle, Send, Trash2, Wrench, User as UserIcon,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { api } from "./api";
import { cn } from "@/lib/utils";

export function TaskTable({
  tasks,
  issues,
  comments,
  warningDays,
  userName,
  onChanged,
  selectedTaskId,
  members,
}: {
  tasks: TaskT[];
  issues: IssueT[];
  comments: CommentT[];
  warningDays: number;
  userName: string;
  members: string[];
  onChanged: () => void;
  selectedTaskId?: string | null;
}) {
  const { toast } = useToast();
  const [expanded, setExpanded] = useState<Set<string>>(new Set(selectedTaskId ? [selectedTaskId] : []));
  const [commentDraft, setCommentDraft] = useState<Record<string, string>>({});
  const [issueTarget, setIssueTarget] = useState<TaskT | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<TaskT | null>(null);
  const [newTaskOpen, setNewTaskOpen] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskAssignee, setNewTaskAssignee] = useState("");
  const [newTaskDue, setNewTaskDue] = useState<string | null>(null);

  function toggle(id: string) {
    setExpanded((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  }

  async function updateTask(t: TaskT, patch: Record<string, unknown>, msg: string) {
    try {
      await api.updateTask(t.id, patch);
      toast({ title: msg, description: `${t.title}` });
      onChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  async function addComment(t: TaskT) {
    const body = (commentDraft[t.id] ?? "").trim();
    if (!body) return;
    try {
      await api.createComment({ taskId: t.id, body });
      setCommentDraft((d) => ({ ...d, [t.id]: "" }));
      toast({ title: "کامنت ثبت شد" });
      onChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  async function addNewTask() {
    if (!newTaskTitle.trim()) return;
    try {
      await api.createTask({
        projectId: tasks[0]?.projectId,
        title: newTaskTitle.trim(),
        assignee: newTaskAssignee.trim(),
        dueDate: newTaskDue,
        description: "",
      });
      setNewTaskTitle(""); setNewTaskAssignee(""); setNewTaskDue(null);
      setNewTaskOpen(false);
      toast({ title: "کار جدید اضافه شد" });
      onChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  return (
    <div className="rounded-xl border bg-card overflow-hidden">
      <div className="flex items-center justify-between p-3 border-b bg-muted/40">
        <h3 className="text-sm font-bold">کارهای پروژه ({faNum(tasks.length)})</h3>
        <Button size="sm" variant="outline" onClick={() => setNewTaskOpen((v) => !v)} className="gap-1.5">
          <PlusCircle className="h-4 w-4" /> افزودن کار
        </Button>
      </div>

      {newTaskOpen && (
        <div className="p-3 border-b bg-accent/30 grid sm:grid-cols-4 gap-2 items-end">
          <div className="sm:col-span-2 space-y-1">
            <label className="text-xs font-semibold">عنوان کار *</label>
            <Input value={newTaskTitle} onChange={(e) => setNewTaskTitle(e.target.value)} placeholder="مثال: نصب سکتور آنتن" />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold">مسئول</label>
            <Input value={newTaskAssignee} onChange={(e) => setNewTaskAssignee(e.target.value)} placeholder="نام شخص" list="members-list" />
            <datalist id="members-list">{members.map((m) => <option key={m} value={m} />)}</datalist>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold">ددلاین</label>
            <JalaliDatePicker value={newTaskDue} onChange={setNewTaskDue} className="w-full" clearable />
          </div>
          <Button size="sm" className="sm:col-span-4" onClick={addNewTask} disabled={!newTaskTitle.trim()}>ثبت کار</Button>
        </div>
      )}

      <div className="overflow-x-auto custom-scrollbar">
        <table className="w-full text-sm min-w-[980px]">
          <thead>
            <tr className="text-xs text-muted-foreground border-b bg-slate-50">
              <th className="w-8 p-2.5 text-center">#</th>
              <th className="p-2.5 text-right min-w-44">عنوان کار</th>
              <th className="p-2.5 text-center w-36">وضعیت</th>
              <th className="p-2.5 text-center w-40">پیشرفت</th>
              <th className="p-2.5 text-center w-36">شروع</th>
              <th className="p-2.5 text-center w-36">ددلاین</th>
              <th className="p-2.5 text-center w-36">چراغ وضعیت</th>
              <th className="p-2.5 text-center w-12">جزئیات</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((t) => {
              const c = computeTask(t, issues, comments, warningDays);
              const isOpen = expanded.has(t.id);
              const lastComment = t.comments.length ? t.comments[t.comments.length - 1] : null;
              return (
                <Fragment key={t.id}>
                  <tr
                    className={cn("border-b transition-colors hover:bg-accent/40", isOpen && "bg-accent/30", selectedTaskId === t.id && "bg-teal-50")}
                  >
                    <td className="p-2.5 text-center font-bold text-muted-foreground">{faNum(t.order)}</td>
                    <td className="p-2.5">
                      <div className="font-semibold leading-5 flex items-center gap-2 flex-wrap">
                        {t.status === "blocked" && <PauseCircle className="h-4 w-4 text-amber-600 shrink-0" />}
                        {t.title}
                      </div>
                      <div className="text-[11px] text-muted-foreground flex items-center gap-2 mt-0.5 flex-wrap">
                        {t.assignee && <span className="inline-flex items-center gap-1"><UserIcon className="h-3 w-3" />{t.assignee}</span>}
                        {t.issues.filter((i) => !i.resolvedAt).length > 0 && (
                          <span className="text-orange-700 font-semibold" title={t.issues.filter((i) => !i.resolvedAt).map((i) => i.title).join("؛ ")}>
                            🔧 {faNum(t.issues.filter((i) => !i.resolvedAt).length)} مشکل باز
                          </span>
                        )}
                        {lastComment && (
                          <span className="truncate max-w-64 inline-flex items-center gap-1" title={lastComment.body}>
                            💬 «{lastComment.body.slice(0, 40)}{lastComment.body.length > 40 ? "…" : ""}»
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-2.5 text-center">
                      <Select value={t.status} onValueChange={(v) => updateTask(t, { status: v }, "وضعیت بروز شد")}>
                        <SelectTrigger className="h-8 text-xs w-32 mx-auto"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {TASK_STATUSES.map((s) => (
                            <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="p-2.5">
                      <div className="flex items-center gap-2">
                        <Slider
                          value={[t.progress]}
                          min={0}
                          max={100}
                          step={5}
                          className="flex-1"
                          onValueCommit={(v) => updateTask(t, { progress: v[0], status: v[0] === 100 ? "done" : t.status === "done" ? "in_progress" : t.status }, "پیشرفت بروز شد")}
                        />
                        <span className="text-xs font-bold w-10 text-center">{faNum(t.progress)}٪</span>
                      </div>
                      <Progress value={t.progress} className="h-1 mt-1.5" />
                    </td>
                    <td className="p-2.5 text-center">
                      <JalaliDatePicker value={t.startDate} onChange={(v) => updateTask(t, { startDate: v }, "تاریخ شروع بروز شد")} className="mx-auto" />
                    </td>
                    <td className="p-2.5 text-center">
                      <JalaliDatePicker value={t.dueDate} onChange={(v) => updateTask(t, { dueDate: v }, "ددلاین بروز شد")} className="mx-auto" />
                    </td>
                    <td className="p-2.5 text-center">
                      <div className="flex flex-col items-center gap-1">
                        <LightBadge light={c.light} label={c.label} />
                        {c.delayDays > 0 && (
                          <span className="text-[10px] font-bold text-red-700" title="بر اساس پیش‌بینی رفع مشکل">
                            ⏱ {faNum(c.delayDays)} روز دیلی
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-2.5 text-center">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggle(t.id)} title="جزئیات، کامنت و مشکلات">
                        <ChevronDown className={cn("h-4 w-4 transition-transform", isOpen && "rotate-180")} />
                      </Button>
                    </td>
                  </tr>

                  {isOpen && (
                    <tr className="bg-slate-50/60 border-b">
                      <td colSpan={8} className="p-4">
                        <div className="grid lg:grid-cols-2 gap-4">
                          {/* توضیحات و ویرایش */}
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <h4 className="text-xs font-bold text-muted-foreground">ویرایش کار</h4>
                              <Button variant="ghost" size="sm" className="text-destructive h-7 text-xs gap-1" onClick={() => setDeleteTarget(t)}>
                                <Trash2 className="h-3.5 w-3.5" /> حذف کار
                              </Button>
                            </div>
                            <Input
                              defaultValue={t.title}
                              onBlur={(e) => e.target.value !== t.title && updateTask(t, { title: e.target.value }, "عنوان بروز شد")}
                              placeholder="عنوان کار"
                              className="h-9"
                            />
                            <Textarea
                              defaultValue={t.description}
                              onBlur={(e) => e.target.value !== t.description && updateTask(t, { description: e.target.value }, "توضیحات بروز شد")}
                              placeholder="توضیحات کار..."
                              rows={2}
                            />
                            <div className="grid grid-cols-2 gap-2">
                              <div className="relative">
                                <UserIcon className="absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                                <Input
                                  defaultValue={t.assignee}
                                  onBlur={(e) => e.target.value !== t.assignee && updateTask(t, { assignee: e.target.value }, "مسئول بروز شد")}
                                  placeholder="مسئول"
                                  className="pr-8 h-9 text-xs"
                                  list="members-list"
                                />
                              </div>
                              <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground justify-center">
                                <CalendarDays className="h-3.5 w-3.5" />
                                امروز: {formatJalali(todayStr())}
                              </div>
                            </div>
                          </div>

                          {/* مشکلات باز */}
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <h4 className="text-xs font-bold text-muted-foreground flex items-center gap-1">
                                <Wrench className="h-3.5 w-3.5" /> مشکلات این کار ({faNum(t.issues.length)})
                              </h4>
                              <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => setIssueTarget(t)}>
                                <PlusCircle className="h-3 w-3" /> ثبت مشکل
                              </Button>
                            </div>
                            {t.issues.length === 0 && <p className="text-xs text-muted-foreground py-1">مشکلی ثبت نشده</p>}
                            <div className="space-y-2 max-h-40 overflow-y-auto custom-scrollbar">
                              {t.issues.map((i) => (
                                <IssueChip key={i.id} issue={i} onChanged={onChanged} />
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* کامنت‌ها */}
                        <div className="mt-4 pt-3 border-t space-y-2">
                          <h4 className="text-xs font-bold text-muted-foreground">کامنت‌ها — دلیل توقف و گزارش وضعیت ({faNum(t.comments.length)})</h4>
                          <div className="space-y-1.5 max-h-36 overflow-y-auto custom-scrollbar">
                            {t.comments.map((cm) => (
                              <CommentRow key={cm.id} comment={cm} onChanged={onChanged} />
                            ))}
                            {t.comments.length === 0 && <p className="text-xs text-muted-foreground">اولین کامنت را ثبت کنید</p>}
                          </div>
                          <div className="flex gap-2">
                            <Input
                              value={commentDraft[t.id] ?? ""}
                              onChange={(e) => setCommentDraft((d) => ({ ...d, [t.id]: e.target.value }))}
                              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); addComment(t); } }}
                              placeholder={`کامنت به نام ${userName} — مثلاً دلیل توقف یا گزارش پیشرفت`}
                              className="h-9 text-xs"
                            />
                            <Button size="icon" className="h-9 w-9 shrink-0" onClick={() => addComment(t)} disabled={!(commentDraft[t.id] ?? "").trim()}>
                              <Send className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </Fragment>
              );
            })}
            {tasks.length === 0 && (
              <tr><td colSpan={8} className="p-8 text-center text-muted-foreground text-sm">هنوز کاری تعریف نشده — با «افزودن کار» شروع کنید</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* دیالوگ ثبت مشکل */}
      <IssueDialog
        task={issueTarget}
        onClose={() => setIssueTarget(null)}
        onCreated={() => { setIssueTarget(null); onChanged(); }}
      />

      {/* تایید حذف کار */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف کار</AlertDialogTitle>
            <AlertDialogDescription>
              «{deleteTarget?.title}» و کامنت‌ها و مشکلات آن حذف می‌شود. مطمئنید؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={async () => {
                if (deleteTarget) {
                  try {
                    await api.deleteTask(deleteTarget.id);
                    toast({ title: "کار حذف شد" });
                    onChanged();
                  } catch (e) {
                    toast({ title: "خطا", description: String(e), variant: "destructive" });
                  }
                }
                setDeleteTarget(null);
              }}
            >
              حذف قطعی
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export function IssueChip({ issue, onChanged }: { issue: IssueT; onChanged: () => void }) {
  const { toast } = useToast();
  const isResolved = !!issue.resolvedAt;
  return (
    <div className={cn("rounded-lg border p-2.5 space-y-1", isResolved ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200")}>
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-bold">{issue.title}</span>
        <div className="flex items-center gap-1">
          {!isResolved ? (
            <Button
              variant="ghost" size="sm" className="h-6 text-[11px] text-emerald-700 hover:text-emerald-800"
              onClick={async () => {
                try {
                  await api.updateIssue(issue.id, { resolved: true });
                  toast({ title: "مشکل به عنوان رفع‌شده ثبت شد" });
                  onChanged();
                } catch (e) { toast({ title: "خطا", description: String(e), variant: "destructive" }); }
              }}
            >
              رفع شد
            </Button>
          ) : (
            <span className="text-[10px] text-emerald-700 font-semibold">رفع شده در {formatJalali(issue.resolvedAt)}</span>
          )}
          <Button
            variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground"
            title="حذف مشکل"
            onClick={async () => {
              try {
                await api.deleteIssue(issue.id);
                toast({ title: "مشکل حذف شد" });
                onChanged();
              } catch (e) { toast({ title: "خطا", description: String(e), variant: "destructive" }); }
            }}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </div>
      {issue.description && <p className="text-[11px] text-muted-foreground leading-4">{issue.description}</p>}
      <div className="text-[10px] flex flex-wrap gap-2 text-muted-foreground">
        <span>بروز: <b>{formatJalali(issue.occurredAt)}</b></span>
        <span>پیش‌بینی رفع: <b className={isResolved ? "" : "text-amber-700"}>{formatJalali(issue.estimatedResolveAt)}</b></span>
        {issue.createdBy && <span>ثبت‌کننده: {issue.createdBy}</span>}
      </div>
    </div>
  );
}

function CommentRow({ comment, onChanged }: { comment: CommentT; onChanged: () => void }) {
  const { toast } = useToast();
  return (
    <div className="rounded-lg bg-card border px-3 py-2 flex items-start gap-2 group">
      <div className="min-w-0 flex-1">
        <p className="text-xs leading-5 whitespace-pre-wrap">{comment.body}</p>
        <p className="text-[10px] text-muted-foreground mt-0.5">
          {comment.authorName} · {formatJalali(comment.createdAt.slice(0, 10))}
        </p>
      </div>
      <Button
        variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 text-muted-foreground"
        title="حذف کامنت"
        onClick={async () => {
          try {
            await api.deleteComment(comment.id);
            toast({ title: "کامنت حذف شد" });
            onChanged();
          } catch (e) {
            toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
          }
        }}
      >
        <Trash2 className="h-3 w-3" />
      </Button>
    </div>
  );
}

/** دیالوگ ثبت مشکل جدید — شامل تاریخ بروز + ستون پیش‌بینی رفع */
export function IssueDialog({
  task, projectId, onClose, onCreated,
}: {
  task?: TaskT | null;
  projectId?: string;
  onClose: () => void;
  onCreated: () => void;
}) {
  const { toast } = useToast();
  const open = !!task;
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [occurredAt, setOccurredAt] = useState<string | null>(todayStr());
  const [estimate, setEstimate] = useState<string | null>(null);

  function resetFields() {
    setTitle("");
    setDescription("");
    setOccurredAt(todayStr());
    setEstimate(null);
  }

  async function submit() {
    if (!title.trim()) { toast({ title: "خطا", description: "عنوان مشکل الزامی است", variant: "destructive" }); return; }
    if (!occurredAt || !estimate) { toast({ title: "خطا", description: "تاریخ بروز و پیش‌بینی رفع الزامی است", variant: "destructive" }); return; }
    try {
      await api.createIssue({
        taskId: task?.id ?? null,
        projectId: task?.projectId ?? projectId,
        title: title.trim(),
        description,
        occurredAt,
        estimatedResolveAt: estimate,
      });
      setTitle(""); setDescription(""); setEstimate(null);
      toast({ title: "مشکل ثبت شد", description: "دیلی بر اساس پیش‌بینی رفع محاسبه می‌شود" });
      onCreated();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  return (
    <AlertDialog open={open} onOpenChange={(v) => { if (!v) { resetFields(); onClose(); } }}>
      <AlertDialogContent dir="rtl" className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <MessageSquarePlus className="h-5 w-5 text-orange-600" /> ثبت مشکل {task ? `برای «${task.title}»` : "برای پروژه"}
          </AlertDialogTitle>
          <AlertDialogDescription>
            تاریخ بروز مشکل و پیش‌بینی رفع را ثبت کنید؛ سیستم دیلی را نسبت به ددلاین به‌روز نگه می‌دارد.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <label className="text-xs font-semibold">عنوان مشکل *</label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثال: شکستگی ستون هنگام حمل" />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold">توضیح / دلیل</label>
            <Textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="شرح مشکل و اقدامات..." />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-semibold">تاریخ بروز *</label>
              <JalaliDatePicker value={occurredAt} onChange={setOccurredAt} className="w-full" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold">پیش‌بینی رفع *</label>
              <JalaliDatePicker value={estimate} onChange={setEstimate} className="w-full" placeholder="کی حل می‌شود؟" />
            </div>
          </div>
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel>انصراف</AlertDialogCancel>
          <Button onClick={submit}>ثبت مشکل</Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
