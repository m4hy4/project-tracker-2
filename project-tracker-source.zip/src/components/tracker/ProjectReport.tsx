"use client";

import { ProjectT, Settings } from "./types";
import { computeProject, computeTask, statusLabel, TASK_STATUSES } from "@/lib/status";
import { faNum, formatJalali, formatJalaliLong, todayStr } from "@/lib/jalali";
import { LightBadge } from "./StatusLight";
import { Pipeline } from "./Pipeline";
import { reportDate } from "./ExportMenu";

/** گزارش چاپی ارائه — با @media print به‌صورت PDF یک‌صفحه‌ای A4 افقی خروجی می‌گیرد */
export function ProjectReport({ project, settings }: { project: ProjectT; settings: Settings }) {
  const computed = computeProject(project, project.tasks, project.issues, project.comments, settings.warningDays);
  const today = todayStr();
  const doneTasks = project.tasks.filter((t) => t.status === "done").length;
  const blockedTasks = project.tasks.filter((t) => t.status === "blocked").length;
  const openIssues = project.issues.filter((i) => !i.resolvedAt).length;
  const progress = project.tasks.length
    ? Math.round(project.tasks.reduce((a, t) => a + t.progress, 0) / project.tasks.length)
    : 0;

  const statusCounts = TASK_STATUSES.map((s) => ({
    ...s,
    count: project.tasks.filter((t) => t.status === s.value).length,
  }));

  return (
    <div id="print-report" dir="rtl" className="bg-white text-neutral-900 p-6 text-[12px]">
      {/* سربرگ با لوگوی ایرانسل */}
      <div className="flex items-center gap-3 border-b-2 border-neutral-900 pb-3 mb-4">
        <img src="/irancell-logo.png" alt="ایرانسل" className="h-12 object-contain" />
        <div className="flex-1">
          <h1 className="text-xl font-bold leading-tight">گزارش پروژه: {project.name}</h1>
          <p className="text-[11px] text-neutral-600">
            سرویس: {project.service.name} · مسئول: {project.ownerName || "—"} · محل: {project.location || "—"}
          </p>
        </div>
        <div className="text-left">
          <p className="text-[11px] text-neutral-600">تاریخ گزارش</p>
          <p className="text-sm font-bold">{reportDate()}</p>
        </div>
      </div>

      {/* خلاصه وضعیت */}
      <div className="grid grid-cols-6 gap-2 mb-4 print-avoid-break">
        <Box label="چراغ وضعیت">
          <LightBadge light={computed.light} label={computed.label} className="text-sm" />
        </Box>
        <Box label="پیشرفت کل"><Big>{faNum(progress)}٪</Big></Box>
        <Box label="کارها"><Big>{faNum(doneTasks)}<Small>/{faNum(project.tasks.length)}</Small></Big></Box>
        <Box label="متوقف (blocked)"><Big className={blockedTasks ? "text-amber-700" : ""}>{faNum(blockedTasks)}</Big></Box>
        <Box label="مشکلات باز"><Big className={openIssues ? "text-orange-700" : ""}>{faNum(openIssues)}</Big></Box>
        <Box label="دیلی پروژه"><Big className={computed.delayDays ? "text-red-700" : "text-emerald-700"}>{faNum(computed.delayDays)} روز</Big></Box>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4 text-[11px] print-avoid-break">
        <div className="rounded border p-2.5">
          <p className="font-bold mb-1">توضیحات سرویس</p>
          <p className="text-neutral-700 leading-5">{project.service.description || "—"}</p>
          <p className="font-bold mt-2 mb-1">قابلیت‌های سرویس</p>
          <ul className="list-disc pr-4 text-neutral-700 space-y-0.5">
            {project.service.capabilities.map((c) => <li key={c}>{c}</li>)}
          </ul>
        </div>
        <div className="rounded border p-2.5">
          <p className="font-bold mb-1">زمان‌بندی پروژه</p>
          <p>شروع: <b>{formatJalali(project.startDate)}</b></p>
          <p>ددلاین اعلامی: <b>{formatJalali(project.dueDate)}</b></p>
          <p>ددلاین مؤثر (با پیش‌بینی رفع مشکلات): <b>{formatJalali(computed.effectiveDeadline)}</b></p>
          <div className="flex gap-2 flex-wrap mt-1.5">
            {statusCounts.map((s) => (
              <span key={s.value} className="rounded bg-neutral-100 px-2 py-0.5">
                {s.label}: <b>{faNum(s.count)}</b>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* پایپ‌لاین */}
      <div className="mb-4 print-avoid-break">
        <h2 className="font-bold text-sm mb-2">پایپ‌لاین — موقعیت فعلی پروژه</h2>
        <Pipeline tasks={project.tasks} issues={project.issues} comments={project.comments} warningDays={settings.warningDays} />
      </div>

      {/* جدول کارها */}
      <h2 className="font-bold text-sm mb-2">جزئیات کارها</h2>
      <table className="w-full border-collapse text-[10.5px] mb-4 print-avoid-break">
        <thead>
          <tr className="bg-neutral-100">
            <th className="border p-1.5">#</th>
            <th className="border p-1.5 text-right">عنوان کار</th>
            <th className="border p-1.5">مسئول</th>
            <th className="border p-1.5">وضعیت</th>
            <th className="border p-1.5">پیشرفت</th>
            <th className="border p-1.5">شروع</th>
            <th className="border p-1.5">ددلاین مؤثر</th>
            <th className="border p-1.5">چراغ / دیلی</th>
            <th className="border p-1.5 text-right">آخرین کامنت / دلیل توقف</th>
          </tr>
        </thead>
        <tbody>
          {project.tasks.map((t) => {
            const c = computeTask(t, project.issues, project.comments, settings.warningDays, today);
            const last = t.comments.length ? t.comments[t.comments.length - 1] : null;
            const reason = t.status === "blocked" ? c.blockedReason ?? "" : "";
            return (
              <tr key={t.id}>
                <td className="border p-1.5 text-center">{faNum(t.order)}</td>
                <td className="border p-1.5 font-semibold">{t.title}</td>
                <td className="border p-1.5 text-center">{t.assignee || "—"}</td>
                <td className="border p-1.5 text-center">{statusLabel(t.status)}</td>
                <td className="border p-1.5 text-center">{faNum(t.progress)}٪</td>
                <td className="border p-1.5 text-center">{formatJalali(t.startDate)}</td>
                <td className="border p-1.5 text-center">{formatJalali(c.effectiveDeadline)}</td>
                <td className="border p-1.5 text-center">
                  <LightBadge light={c.light} label={c.label} className="text-[9px]" />
                </td>
                <td className="border p-1.5 text-right leading-4">
                  {reason ? <b className="text-red-700">⛔ {reason}</b> : last ? last.body : "—"}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {/* جدول مشکلات */}
      {project.issues.length > 0 && (
        <>
          <h2 className="font-bold text-sm mb-2">مشکلات ثبت‌شده و پیش‌بینی رفع</h2>
          <table className="w-full border-collapse text-[10.5px] mb-3 print-avoid-break">
            <thead>
              <tr className="bg-neutral-100">
                <th className="border p-1.5 text-right">مشکل</th>
                <th className="border p-1.5 text-right">مربوط به</th>
                <th className="border p-1.5">تاریخ بروز</th>
                <th className="border p-1.5">پیش‌بینی رفع</th>
                <th className="border p-1.5">وضعیت</th>
              </tr>
            </thead>
            <tbody>
              {project.issues.map((i) => {
                const task = project.tasks.find((t) => t.id === i.taskId);
                return (
                  <tr key={i.id} className={i.resolvedAt ? "" : "bg-red-50/60"}>
                    <td className="border p-1.5 font-semibold">{i.title}</td>
                    <td className="border p-1.5">{task ? task.title : "کل پروژه"}</td>
                    <td className="border p-1.5 text-center">{formatJalali(i.occurredAt)}</td>
                    <td className="border p-1.5 text-center">{formatJalali(i.estimatedResolveAt)}</td>
                    <td className="border p-1.5 text-center">{i.resolvedAt ? `رفع شد (${formatJalali(i.resolvedAt)})` : "باز"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </>
      )}

      <p className="text-[9px] text-neutral-400 text-left">
        خروجی سامانه ردیابی پروژه‌ها · {formatJalaliLong(today)}
      </p>
    </div>
  );
}

function Box({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded border p-2 text-center">
      <p className="text-[9px] text-neutral-500 mb-1">{label}</p>
      {children}
    </div>
  );
}
function Big({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <span className={`text-base font-bold ${className}`}>{children}</span>;
}
function Small({ children }: { children: React.ReactNode }) {
  return <span className="text-[10px] text-neutral-500">{children}</span>;
}
