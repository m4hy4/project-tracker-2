"use client";

import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { JalaliDatePicker } from "./JalaliDatePicker";
import { api } from "./api";
import { ProjectT, Service } from "./types";
import { ListPlus, Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const PRESET_COLORS = ["#0d9488", "#7c3aed", "#ea580c", "#16a34a", "#dc2626", "#0891b2", "#ca8a04"];

/** دیالوگ ساخت/ویرایش سرویس — شامل باکس توضیحات و لیست قابلیت‌ها */
export function ServiceDialog({
  open,
  onOpenChange,
  initial,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial?: Service | null;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [caps, setCaps] = useState<string[]>([]);
  const [capInput, setCapInput] = useState("");
  const [color, setColor] = useState(PRESET_COLORS[0]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setName(initial?.name ?? "");
      setDescription(initial?.description ?? "");
      setCaps(initial?.capabilities ? [...initial.capabilities] : []);
      setColor(initial?.color ?? PRESET_COLORS[0]);
      setCapInput("");
    }
  }, [open, initial]);

  function addCap() {
    const v = capInput.trim();
    if (!v) return;
    setCaps((c) => [...c, v]);
    setCapInput("");
  }

  async function save() {
    if (!name.trim()) {
      toast({ title: "خطا", description: "نام سرویس الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      if (initial) {
        await api.updateService(initial.id, { name: name.trim(), description, capabilities: caps, color });
        toast({ title: "ذخیره شد", description: "سرویس بروزرسانی شد" });
      } else {
        await api.createService({ name: name.trim(), description, capabilities: caps, color });
        toast({ title: "سرویس ساخته شد", description: `«${name.trim()}» به فهرست سرویس‌ها اضافه شد` });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto custom-scrollbar">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ListPlus className="h-5 w-5 text-primary" />
            {initial ? "ویرایش سرویس" : "سرویس جدید"}
          </DialogTitle>
          <DialogDescription>
            تعریف سرویس پایه: نام، باکس توضیحات و قابلیت‌هایی که هنگام ساخت پروژه نمایش داده می‌شود.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>نام سرویس *</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: نصب و راه‌اندازی سایت BTS" />
          </div>
          <div className="space-y-1.5">
            <Label>باکس توضیحات سرویس</Label>
            <Textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="این سرویس چه کاری انجام می‌دهد و خروجی آن چیست؟" />
          </div>

          <div className="space-y-1.5">
            <Label>قابلیت‌های سرویس ({caps.length} مورد)</Label>
            <div className="space-y-1.5 max-h-40 overflow-y-auto custom-scrollbar">
              {caps.map((c, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="flex-1 text-sm bg-muted rounded-md px-3 py-1.5">{c}</span>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setCaps((arr) => arr.filter((_, j) => j !== i))}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
              {caps.length === 0 && <p className="text-xs text-muted-foreground py-1.5">هنوز قابلیتی ثبت نشده است</p>}
            </div>
            <div className="flex gap-2">
              <Input
                value={capInput}
                onChange={(e) => setCapInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addCap(); } }}
                placeholder="قابلیت جدید و Enter"
              />
              <Button type="button" variant="outline" size="icon" onClick={addCap}><Plus className="h-4 w-4" /></Button>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>رنگ سرویس</Label>
            <div className="flex gap-2">
              {PRESET_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`h-7 w-7 rounded-full border-2 transition-transform ${color === c ? "border-neutral-900 scale-110" : "border-transparent"}`}
                  style={{ backgroundColor: c }}
                  aria-label={c}
                />
              ))}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving}>{saving ? "در حال ذخیره..." : "ذخیره سرویس"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** دیالوگ ساخت/ویرایش پروژه */
export function ProjectDialog({
  open,
  onOpenChange,
  initial,
  services,
  defaultServiceId,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial?: ProjectT | null;
  services: Service[];
  defaultServiceId?: string;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [serviceId, setServiceId] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [status, setStatus] = useState("active");
  const [startDate, setStartDate] = useState<string | null>(null);
  const [dueDate, setDueDate] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setName(initial?.name ?? "");
      setServiceId(initial?.serviceId ?? defaultServiceId ?? services[0]?.id ?? "");
      setDescription(initial?.description ?? "");
      setLocation(initial?.location ?? "");
      setOwnerName(initial?.ownerName ?? "");
      setStatus(initial?.status ?? "active");
      setStartDate(initial?.startDate ?? null);
      setDueDate(initial?.dueDate ?? null);
    }
  }, [open, initial, services, defaultServiceId]);

  async function save() {
    if (!name.trim()) { toast({ title: "خطا", description: "نام پروژه الزامی است", variant: "destructive" }); return; }
    if (!serviceId) { toast({ title: "خطا", description: "انتخاب سرویس الزامی است", variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (initial) {
        await api.updateProject(initial.id, {
          name: name.trim(), serviceId, description, location, ownerName, status, startDate, dueDate,
        });
        toast({ title: "ذخیره شد", description: "پروژه بروزرسانی شد" });
      } else {
        await api.createProject({
          name: name.trim(), serviceId, description, location, ownerName, startDate, dueDate,
        } as Partial<ProjectT>);
        toast({ title: "پروژه ساخته شد", description: `«${name.trim()}» آماده تعریف کارهاست` });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto custom-scrollbar">
        <DialogHeader>
          <DialogTitle>{initial ? "ویرایش پروژه" : "پروژه جدید"}</DialogTitle>
          <DialogDescription>
            پروژه روی یکی از سرویس‌ها سوار می‌شود؛ قابلیت‌های سرویس در صفحه پروژه نمایش داده می‌شود.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5 col-span-2">
              <Label>نام پروژه *</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: سایت BTS پونک — فاز ۲" />
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>سرویس *</Label>
              <Select value={serviceId} onValueChange={setServiceId}>
                <SelectTrigger><SelectValue placeholder="انتخاب سرویس" /></SelectTrigger>
                <SelectContent>
                  {services.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      <span className="inline-flex items-center gap-2">
                        <span className="h-2.5 w-2.5 rounded-full inline-block" style={{ backgroundColor: s.color }} />
                        {s.name}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>مسئول پروژه</Label>
              <Input value={ownerName} onChange={(e) => setOwnerName(e.target.value)} placeholder="نام مسئول" />
            </div>
            <div className="space-y-1.5">
              <Label>محل / سایت</Label>
              <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="مثال: تهران، پونک" />
            </div>
            <div className="space-y-1.5">
              <Label>تاریخ شروع</Label>
              <JalaliDatePicker value={startDate} onChange={setStartDate} className="w-full" placeholder="شروع" />
            </div>
            <div className="space-y-1.5">
              <Label>ددلاین کل پروژه</Label>
              <JalaliDatePicker value={dueDate} onChange={setDueDate} className="w-full" placeholder="ددلاین" />
            </div>
            {initial && (
              <div className="space-y-1.5 col-span-2">
                <Label>وضعیت پروژه</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">فعال</SelectItem>
                    <SelectItem value="paused">متوقف</SelectItem>
                    <SelectItem value="done">تمام‌شده</SelectItem>
                    <SelectItem value="cancelled">لغوشده</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-1.5 col-span-2">
              <Label>توضیحات پروژه</Label>
              <Textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="هدف و شرح کوتاه پروژه" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving}>{saving ? "در حال ذخیره..." : "ذخیره پروژه"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
