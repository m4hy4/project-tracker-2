import { ProjectT, Service, User } from "./types";

async function req<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options?.headers ?? {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || "خطای ناشناخته در ارتباط با سرور");
  }
  return data as T;
}

function parseService(s: Record<string, unknown>): Service {
  let caps: string[] = [];
  try {
    caps = JSON.parse((s.capabilities as string) || "[]");
  } catch {
    caps = [];
  }
  return { ...(s as unknown as Service), capabilities: caps };
}

function parseProject(p: Record<string, unknown>): ProjectT {
  const proj = { ...(p as unknown as ProjectT) };
  proj.service = parseService(proj.service as unknown as Record<string, unknown>);
  proj.tasks = proj.tasks ?? [];
  proj.issues = proj.issues ?? [];
  proj.comments = proj.comments ?? [];
  for (const t of proj.tasks) {
    t.comments = t.comments ?? [];
    t.issues = t.issues ?? [];
  }
  return proj;
}

export const api = {
  // ---- auth ----
  async login(username: string, password: string): Promise<{ user: User }> {
    return req("/api/auth/login", { method: "POST", body: JSON.stringify({ username, password }) });
  },
  async logout(): Promise<void> {
    await req("/api/auth/logout", { method: "POST" });
  },
  async me(): Promise<{ user: User | null }> {
    return req("/api/auth/me");
  },

  // ---- users ----
  async users(): Promise<{ users: User[] }> {
    return req("/api/users");
  },
  async createUser(d: { username: string; name: string; password: string; role: string }): Promise<void> {
    await req("/api/users", { method: "POST", body: JSON.stringify(d) });
  },
  async updateUser(id: string, d: { name?: string; password?: string; role?: string }): Promise<void> {
    await req(`/api/users/${id}`, { method: "PUT", body: JSON.stringify(d) });
  },
  async deleteUser(id: string): Promise<void> {
    await req(`/api/users/${id}`, { method: "DELETE" });
  },

  // ---- services ----
  async services(): Promise<{ services: Record<string, unknown>[] }> {
    return req("/api/services");
  },
  async createService(d: { name: string; description: string; capabilities: string[]; color: string; icon?: string }): Promise<void> {
    await req("/api/services", { method: "POST", body: JSON.stringify(d) });
  },
  async updateService(id: string, d: { name?: string; description?: string; capabilities?: string[]; color?: string; icon?: string }): Promise<void> {
    await req(`/api/services/${id}`, { method: "PUT", body: JSON.stringify(d) });
  },
  async deleteService(id: string): Promise<void> {
    await req(`/api/services/${id}`, { method: "DELETE" });
  },

  // ---- projects ----
  async projects(): Promise<{ projects: Record<string, unknown>[] }> {
    return req("/api/projects");
  },
  async createProject(d: Partial<ProjectT>): Promise<void> {
    await req("/api/projects", { method: "POST", body: JSON.stringify(d) });
  },
  async updateProject(id: string, d: Partial<ProjectT>): Promise<void> {
    await req(`/api/projects/${id}`, { method: "PUT", body: JSON.stringify(d) });
  },
  async deleteProject(id: string): Promise<void> {
    await req(`/api/projects/${id}`, { method: "DELETE" });
  },

  // ---- tasks ----
  async createTask(d: { projectId: string; title: string; assignee?: string; startDate?: string | null; dueDate?: string | null; description?: string }): Promise<void> {
    await req("/api/tasks", { method: "POST", body: JSON.stringify(d) });
  },
  async updateTask(id: string, d: Record<string, unknown>): Promise<void> {
    await req(`/api/tasks/${id}`, { method: "PUT", body: JSON.stringify(d) });
  },
  async deleteTask(id: string): Promise<void> {
    await req(`/api/tasks/${id}`, { method: "DELETE" });
  },

  // ---- issues ----
  async createIssue(d: { projectId?: string; taskId?: string | null; title: string; description?: string; occurredAt: string; estimatedResolveAt: string }): Promise<void> {
    await req("/api/issues", { method: "POST", body: JSON.stringify(d) });
  },
  async updateIssue(id: string, d: Record<string, unknown>): Promise<void> {
    await req(`/api/issues/${id}`, { method: "PUT", body: JSON.stringify(d) });
  },
  async deleteIssue(id: string): Promise<void> {
    await req(`/api/issues/${id}`, { method: "DELETE" });
  },

  // ---- comments ----
  async createComment(d: { taskId?: string | null; projectId?: string | null; body: string }): Promise<void> {
    await req("/api/comments", { method: "POST", body: JSON.stringify(d) });
  },
  async deleteComment(id: string): Promise<void> {
    await req(`/api/comments/${id}`, { method: "DELETE" });
  },

  // ---- settings ----
  async settings(): Promise<{ settings: Record<string, string> }> {
    return req("/api/settings");
  },
  async updateSettings(d: { warningDays: number }): Promise<void> {
    await req("/api/settings", { method: "PUT", body: JSON.stringify(d) });
  },
};

export function normalizeServices(raw: Record<string, unknown>[]): Service[] {
  return raw.map((s) => parseService(s));
}

export function normalizeProjects(raw: Record<string, unknown>[]): ProjectT[] {
  return raw.map((p) => parseProject(p));
}
