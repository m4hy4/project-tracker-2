"use client";

import { useMemo, useState } from "react";
import { ProjectT, Service, Settings } from "./types";
import { computeProject, Light } from "@/lib/status";
import { faNum, formatJalali } from "@/lib/jalali";
import { LightBadge } from "./StatusLight";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import {
  AlertTriangle, ArrowLeft, BriefcaseBusiness, Clock, FolderKanban, ListChecks,
  MoreVertical, Pencil, Plus, Search, Trash2, TrendingUp, Wrench,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RTooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const LIGHT_ORDER: Record<Light, number> = { red: 0, yellow: 1, green: 2, grey: 3, done: 4 };

export function DashboardView({
  projects,
  services,
  settings,
  onOpenProject,
  onNewProject,
  onNewService,
  onEditProject,
  onDeleteProject,
  onEditService,
  exportIds,
}: {
  projects: ProjectT[];
  services: Service[];
  settings: Settings;
  onOpenProject: (id: string) => void;
  onNewProject: () => void;
  onNewService: () => void;
  onEditProject: (p: ProjectT) => void;
  onDeleteProject: (p: ProjectT) => void;
  onEditService: (s: Service) => void;
  exportIds?: boolean;
}) {
  const [q, setQ] = useState("");
  const [svcFilter, setSvcFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [lightFilter, setLightFilter] = useState("all");
  const [deleteTarget, setDeleteTarget] = useState<ProjectT | null>(null);

  const enriched = useMemo(
    () =>
      projects.map((p) => ({
        project: p,
        computed: computeProject(p, p.tasks, p.issues, p.comments, settings.warningDays),
        progress: p.tasks.length ? Math.round(p.tasks.reduce((a, t) => a + t.progress, 0) / p.tasks.length) : 0,
      })),
    [projects, settings.warningDays]
  );

  const filtered = useMemo(() => {
    let list = enriched;
    if (q.trim()) {
      const needle = q.trim();
      list = list.filter(
        ({ project }) =>
          project.name.includes(needle) ||
          project.location.includes(needle) ||
          project.ownerName.includes(needle) ||
          project.service.name.includes(needle)
      );
    }
    if (svcFilter !== "all") list = list.filter(({ project }) => project.serviceId === svcFilter);
    if (statusFilter !== "all") list = list.filter(({ project }) => project.status === statusFilter);
    if (lightFilter !== "all") list = list.filter(({ computed }) => computed.light === lightFilter);
    return [...list].sort((a, b) => LIGHT_ORDER[a.computed.light] - LIGHT_ORDER[b.computed.light]);
  }, [enriched, q, svcFilter, statusFilter, lightFilter]);

  const kpis = useMemo(() => {
    const active = enriched.filter(({ project }) => project.status === "active");
    return {
      total: enriched.length,
      active: active.length,
      red: active.filter(({ computed }) => computed.light === "red").length,
      yellow: active.filter(({ computed }) => computed.light === "yellow").length,
      green: active.filter(({ computed }) => computed.light === "green").length,
      openIssues: projects.reduce(
        (a, p) => a + p.issues.filter((i) => !i.resolvedAt).length, 0
      ),
      avgProgress: active.length
        ? Math.round(active.reduce((a, { progress }) => a + progress, 0) / active.length)
        : 0,
    };
  }, [enriched, projects]);

  const healthData = useMemo(() => {
    const { green, yellow, red, active, total } = kpis;
    const done = total - active;
    return [
      { name: "در مسیر (سبز)", value: green, color: "#16a34a" },
      { name: "هشدار (زرد)", value: yellow, color: "#d97706" },
      { name: "تأخیر (قرمز)", value: red, color: "#dc2626" },
      { name: "تمام‌شده", value: Math.max(0, done), color: "#64748b" },
    ].filter((d) => d.value > 0);
  }, [kpis]);

  const serviceData = useMemo(
    () =>
      services.map((s) => {
        const list = enriched.filter(({ project }) => project.serviceId === s.id);
        return {
          name: s.name.length > 18 ? s.name.slice(0, 17) + "…" : s.name,
          پروژه‌ها: list.length,
          میانگین‌پیشرفت: list.length
            ? Math.round(list.reduce((a, x) => a + x.progress, 0) / list.length)
            : 0,
          color: s.color,
        };
      }),
    [services, enriched]
  );

  const idAttr = (id: string) => (exportIds ? { id } : {});

  return (
    <div className="space-y-6">
      {/* دکمه‌های ساخت */}
      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={onNewProject} className="gap-2">
          <Plus className="h-4 w-4" /> پروژه جدید
        </Button>
        <Button variant="outline" onClick={onNewService} className="gap-2">
          <BriefcaseBusiness className="h-4 w-4" /> سرویس جدید
        </Button>
        <div className="mr-auto relative w-64">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی پروژه، سایت، مسئول..." className="pr-9" />
        </div>
      </div>

      {/* کارت‌های KPI */}
      <div id={idAttr("export-kpis") ? "export-kpis" : undefined} className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KpiCard icon={<FolderKanban className="h-4 w-4" />} label="کل پروژه‌ها" value={kpis.total} tone="neutral" />
        <KpiCard icon={<TrendingUp className="h-4 w-4" />} label="فعال" value={kpis.active} tone="teal" />
        <KpiCard icon={<AlertTriangle className="h-4 w-4" />} label="تأخیر (قرمز)" value={kpis.red} tone="red" />
        <KpiCard icon={<Clock className="h-4 w-4" />} label="هشدار (زرد)" value={kpis.yellow} tone="amber" />
        <KpiCard icon={<Wrench className="h-4 w-4" />} label="مشکلات باز" value={kpis.openIssues} tone="orange" />
        <KpiCard icon={<ListChecks className="h-4 w-4" />} label="میانگین پیشرفت" value={`${kpis.avgProgress}٪`} tone="green" />
      </div>

      {/* نمودارها */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card id={idAttr("export-health-chart") ? "export-health-chart" : undefined}>
          <CardContent className="p-4">
            <h3 className="text-sm font-bold mb-2">وضعیت سلامت پروژه‌ها</h3>
            {healthData.length ? (
              <div className="h-56" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={healthData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={2} stroke="#fff">
                      {healthData.map((d) => (
                        <Cell key={d.name} fill={d.color} />
                      ))}
                    </Pie>
                    <RTooltip formatter={(v: number, n: string) => [`${faNum(v)} پروژه`, n]} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="h-56 flex items-center justify-center text-sm text-muted-foreground">دیتایی برای نمایش نیست</p>
            )}
            <div className="flex flex-wrap gap-3 justify-center mt-1">
              {healthData.map((d) => (
                <span key={d.name} className="inline-flex items-center gap-1.5 text-xs">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                  {d.name} ({faNum(d.value)})
                </span>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card id={idAttr("export-service-chart") ? "export-service-chart" : undefined}>
          <CardContent className="p-4">
            <h3 className="text-sm font-bold mb-2">پروژه‌ها و میانگین پیشرفت به تفکیک سرویس</h3>
            <div className="h-64" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={serviceData} margin={{ top: 8, right: 8, left: 8, bottom: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} interval={0} angle={-12} dy={8} />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <RTooltip formatter={(v: number, n: string) => [n === "پروژه‌ها" ? faNum(v) : `${faNum(v)}٪`, n]} />
                  <Bar dataKey="پروژه‌ها" fill="#94a3b8" radius={[4, 4, 0, 0]} maxBarSize={22} />
                  <Bar dataKey="میانگین‌پیشرفت" radius={[4, 4, 0, 0]} maxBarSize={22}>
                    {serviceData.map((d, i) => (
                      <Cell key={i} fill={d.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* فیلترها */}
      <div className="flex flex-wrap gap-2 items-center">
        <Select value={svcFilter} onValueChange={setSvcFilter}>
          <SelectTrigger className="w-52 h-9"><SelectValue placeholder="سرویس" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه سرویس‌ها</SelectItem>
            {services.map((s) => (
              <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40 h-9"><SelectValue placeholder="وضعیت" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            <SelectItem value="active">فعال</SelectItem>
            <SelectItem value="paused">متوقف</SelectItem>
            <SelectItem value="done">تمام‌شده</SelectItem>
            <SelectItem value="cancelled">لغوشده</SelectItem>
          </SelectContent>
        </Select>
        <Select value={lightFilter} onValueChange={setLightFilter}>
          <SelectTrigger className="w-44 h-9"><SelectValue placeholder="چراغ" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه چراغ‌ها</SelectItem>
            <SelectItem value="red">🔴 تأخیر</SelectItem>
            <SelectItem value="yellow">🟡 هشدار</SelectItem>
            <SelectItem value="green">🟢 در مسیر</SelectItem>
            <SelectItem value="done">✅ تمام‌شده</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-xs text-muted-foreground mr-auto">{faNum(filtered.length)} پروژه</span>
      </div>

      {/* کارت‌های پروژه */}
      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed p-10 text-center text-muted-foreground">
          پروژه‌ای با این فیلترها پیدا نشد
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map(({ project, computed, progress }) => (
            <ProjectCard
              key={project.id}
              project={project}
              light={computed.light}
              lightLabel={computed.label}
              delayDays={computed.delayDays}
              progress={progress}
              onOpen={() => onOpenProject(project.id)}
              onEdit={() => onEditProject(project)}
              onDelete={() => setDeleteTarget(project)}
            />
          ))}
        </div>
      )}

      {/* سرویس‌ها — مدیریت سریع */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold">سرویس‌های تعریف‌شده</h3>
            <Button variant="outline" size="sm" onClick={onNewService} className="gap-1.5">
              <Plus className="h-3.5 w-3.5" /> افزودن سرویس
            </Button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {services.map((s) => (
              <div key={s.id} className="rounded-lg border p-3 flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <span className="h-3 w-3 rounded-full shrink-0" style={{ backgroundColor: s.color }} />
                  <span className="font-bold text-sm truncate" title={s.name}>{s.name}</span>
                  <Button variant="ghost" size="icon" className="h-6 w-6 mr-auto shrink-0" onClick={() => onEditService(s)} title="ویرایش سرویس">
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">{s.description || "بدون توضیحات"}</p>
                <div className="text-[11px] text-muted-foreground">
                  {faNum(s.capabilities.length)} قابلیت · {faNum(s._count?.projects ?? 0)} پروژه
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف پروژه</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف «{deleteTarget?.name}» مطمئنید؟ همه کارها، مشکلات و کامنت‌های آن هم حذف می‌شود.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (deleteTarget) onDeleteProject(deleteTarget);
                setDeleteTarget(null);
              }}
            >
              حذف قطعی
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function KpiCard({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number | string; tone: string }) {
  const tones: Record<string, string> = {
    neutral: "bg-slate-100 text-slate-700",
    teal: "bg-teal-100 text-teal-800",
    red: "bg-red-100 text-red-700",
    amber: "bg-amber-100 text-amber-800",
    orange: "bg-orange-100 text-orange-800",
    green: "bg-green-100 text-green-800",
  };
  return (
    <div className="rounded-xl border bg-card p-3.5 flex items-center gap-3">
      <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${tones[tone]}`}>{icon}</div>
      <div className="min-w-0">
        <p className="text-lg font-bold leading-5">{typeof value === "number" ? faNum(value) : value}</p>
        <p className="text-[11px] text-muted-foreground truncate">{label}</p>
      </div>
    </div>
  );
}

function ProjectCard({
  project, light, lightLabel, delayDays, progress, onOpen, onEdit, onDelete,
}: {
  project: ProjectT;
  light: Light;
  lightLabel: string;
  delayDays: number;
  progress: number;
  onOpen: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const doneTasks = project.tasks.filter((t) => t.status === "done").length;
  const openIssues = project.issues.filter((i) => !i.resolvedAt).length;
  return (
    <Card className="group hover:shadow-md transition-shadow overflow-hidden">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <button type="button" onClick={onOpen} className="text-right">
              <h3 className="font-bold text-sm leading-5 hover:text-primary transition-colors line-clamp-1">{project.name}</h3>
            </button>
            <span className="inline-flex items-center gap-1.5 mt-1 text-[11px] text-muted-foreground">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: project.service.color }} />
              {project.service.name}
            </span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0"><MoreVertical className="h-4 w-4" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={onEdit}><Pencil className="h-3.5 w-3.5 ml-1.5" /> ویرایش پروژه</DropdownMenuItem>
              <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive"><Trash2 className="h-3.5 w-3.5 ml-1.5" /> حذف</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center justify-between gap-2 flex-wrap">
          <LightBadge light={light} label={lightLabel} />
          {project.status !== "active" && (
            <span className="text-[10px] bg-muted rounded px-1.5 py-0.5">{project.status === "done" ? "تمام‌شده" : project.status === "paused" ? "متوقف" : "لغوشده"}</span>
          )}
        </div>

        <div>
          <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
            <span>پیشرفت کلی</span>
            <span className="font-bold text-foreground">{faNum(progress)}٪</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <div className="flex items-center gap-3 text-[11px] text-muted-foreground flex-wrap">
          <span title="کارها">✅ {faNum(doneTasks)}/{faNum(project.tasks.length)}</span>
          {openIssues > 0 && <span className="text-orange-700 font-semibold" title="مشکلات باز">🔧 {faNum(openIssues)} مشکل باز</span>}
          {delayDays > 0 && <span className="text-red-700 font-bold" title="روز تأخیر">⏱ {faNum(delayDays)} روز دیلی</span>}
        </div>

        <div className="text-[11px] text-muted-foreground flex items-center gap-2 flex-wrap">
          {project.location && <span>📍 {project.location}</span>}
          {project.ownerName && <span>👤 {project.ownerName}</span>}
          <span>📅 ددلاین: {formatJalali(project.dueDate)}</span>
        </div>

        <Button onClick={onOpen} size="sm" variant="secondary" className="w-full gap-1.5">
          مشاهده پایپ‌لاین و کارها <ArrowLeft className="h-3.5 w-3.5" />
        </Button>
      </CardContent>
    </Card>
  );
}
