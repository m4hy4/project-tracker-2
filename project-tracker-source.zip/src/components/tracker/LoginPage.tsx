"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { api } from "./api";
import { User } from "./types";
import { LogIn, ShieldCheck } from "lucide-react";

export function LoginPage({ onLogin }: { onLogin: (user: User) => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { user } = await api.login(username.trim(), password);
      onLogin(user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطا در ورود");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-neutral-950 via-neutral-900 to-teal-950 p-4" dir="rtl">
      <Card className="w-full max-w-sm shadow-2xl border-none">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-fit rounded-2xl bg-black p-4 mb-2">
            <img src="/irancell-logo.png" alt="لوگوی ایرانسل" className="h-16 object-contain" />
          </div>
          <CardTitle className="text-xl">سامانه ردیابی پروژه‌ها</CardTitle>
          <CardDescription>ورود اعضای تیم — برای مشاهده و بروزرسانی پروژه‌ها</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username">نام کاربری</Label>
              <Input id="username" dir="ltr" className="text-left" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="admin" autoComplete="username" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">پسورد</Label>
              <Input id="password" dir="ltr" className="text-left" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" autoComplete="current-password" />
            </div>
            {error && (
              <div className="rounded-md bg-red-50 border border-red-200 text-red-700 text-xs px-3 py-2">{error}</div>
            )}
            <Button type="submit" className="w-full gap-2" disabled={loading || !username || !password}>
              <LogIn className="h-4 w-4" />
              {loading ? "در حال ورود..." : "ورود به سیستم"}
            </Button>
          </form>
          <div className="mt-4 rounded-md bg-accent border px-3 py-2.5 text-xs text-accent-foreground flex gap-2 items-start">
            <ShieldCheck className="h-4 w-4 mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold mb-1">حساب‌های نمونه (قابل تغییر در تنظیمات):</p>
              <p dir="ltr" className="text-left font-mono leading-5">
                admin / admin123 <span className="opacity-60">(مدیر)</span><br />
                ali / ali123 · sara / sara123 · reza / reza123
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
