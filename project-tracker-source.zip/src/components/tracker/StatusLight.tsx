"use client";

import { Light, LIGHT_COLORS, LIGHT_LABELS } from "@/lib/status";
import { cn } from "@/lib/utils";

/** چراغ وضعیت: سبز / زرد / قرمز — با متن روز مانده یا روز تأخیر */
export function StatusLight({
  light,
  label,
  size = "md",
  className,
}: {
  light: Light;
  label?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}) {
  const dotSize = size === "sm" ? "h-2.5 w-2.5" : size === "lg" ? "h-5 w-5" : "h-3.5 w-3.5";
  const textSize = size === "sm" ? "text-[11px]" : size === "lg" ? "text-base font-bold" : "text-xs";
  const glow =
    light === "red"
      ? "shadow-[0_0_6px_rgba(220,38,38,0.8)]"
      : light === "yellow"
        ? "shadow-[0_0_6px_rgba(217,119,6,0.8)]"
        : light === "green"
          ? "shadow-[0_0_6px_rgba(22,163,74,0.7)]"
          : "";
  return (
    <span className={cn("inline-flex items-center gap-1.5 whitespace-nowrap", className)} title={LIGHT_LABELS[light]}>
      <span className={cn("inline-block rounded-full", dotSize, glow)} style={{ backgroundColor: LIGHT_COLORS[light] }} />
      <span className={cn(textSize, "font-medium text-foreground/80")}>{label ?? LIGHT_LABELS[light]}</span>
    </span>
  );
}

/** نسخه با پس‌زمینه رنگی برای جدول‌ها و کارت‌ها */
export function LightBadge({ light, label, className }: { light: Light; label?: string; className?: string }) {
  const bg: Record<Light, string> = {
    green: "bg-green-100 text-green-800 border-green-200",
    yellow: "bg-amber-100 text-amber-800 border-amber-200",
    red: "bg-red-100 text-red-800 border-red-200",
    done: "bg-emerald-100 text-emerald-800 border-emerald-200",
    grey: "bg-slate-100 text-slate-600 border-slate-200",
  };
  const dot: Record<Light, string> = {
    green: "bg-green-600",
    yellow: "bg-amber-600",
    red: "bg-red-600",
    done: "bg-emerald-600",
    grey: "bg-slate-400",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap",
        bg[light],
        className
      )}
    >
      <span className={cn("h-2 w-2 rounded-full", dot[light])} />
      {label ?? LIGHT_LABELS[light]}
    </span>
  );
}
