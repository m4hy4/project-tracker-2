"use client";

import { useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { CalendarIcon, ChevronLeft, ChevronRight, X } from "lucide-react";
import { toGregorian } from "jalaali-js";
import {
  faNum,
  formatJalali,
  fromJalaliParts,
  jalaliMonthLength,
  jalaliMonthName,
  parseDateStr,
  toJalaliParts,
  todayStr,
} from "@/lib/jalali";
import { cn } from "@/lib/utils";

const WEEK = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

/** تقویم شمسی سبک برای انتخاب تاریخ (YYYY-MM-DD) */
export function JalaliDatePicker({
  value,
  onChange,
  placeholder = "انتخاب تاریخ",
  className,
  clearable = true,
  disabled,
}: {
  value?: string | null;
  onChange: (v: string | null) => void;
  placeholder?: string;
  className?: string;
  clearable?: boolean;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const initial = toJalaliParts(value || todayStr());
  const [jy, setJy] = useState(initial.jy);
  const [jm, setJm] = useState(initial.jm);

  const firstGreg = (function () {
    const { gy, gm, gd } = toGregorian(jy, jm, 1);
    return new Date(gy, gm - 1, gd);
  })();
  const startCol = (firstGreg.getDay() + 1) % 7; // شنبه = ستون ۰
  const monthLen = jalaliMonthLength(jy, jm);
  const today = todayStr();
  const todayParts = toJalaliParts(today);

  function nav(delta: number) {
    let m = jm + delta;
    let y = jy;
    if (m > 12) { m = 1; y++; }
    if (m < 1) { m = 12; y--; }
    setJm(m);
    setJy(y);
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild disabled={disabled}>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className={cn("h-8 justify-start gap-1.5 font-normal", !value && "text-muted-foreground", className)}
        >
          <CalendarIcon className="h-3.5 w-3.5 text-muted-foreground" />
          {value ? formatJalali(value) : placeholder}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-3" align="start">
        <div className="flex items-center justify-between mb-2">
          <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => nav(1)}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="text-sm font-bold">{jalaliMonthName(jm)} {faNum(jy)}</div>
          <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => nav(-1)}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="grid grid-cols-7 gap-0.5 mb-1">
          {WEEK.map((w) => (
            <div key={w} className="text-center text-[10px] font-semibold text-muted-foreground py-1">{w}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-0.5">
          {Array.from({ length: startCol }).map((_, i) => (
            <div key={`e${i}`} />
          ))}
          {Array.from({ length: monthLen }).map((_, i) => {
            const jd = i + 1;
            const dateStr = fromJalaliParts(jy, jm, jd);
            const isToday = dateStr === today;
            const isSelected = value === dateStr;
            return (
              <button
                key={jd}
                type="button"
                onClick={() => { onChange(dateStr); setOpen(false); }}
                className={cn(
                  "h-7 rounded text-xs text-center hover:bg-accent transition-colors",
                  isSelected && "bg-primary text-primary-foreground hover:bg-primary font-bold",
                  !isSelected && isToday && "ring-1 ring-primary font-bold"
                )}
              >
                {faNum(jd)}
              </button>
            );
          })}
        </div>
        <div className="flex items-center justify-between mt-2 pt-2 border-t">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-7 text-xs"
            onClick={() => { onChange(today); setJy(todayParts.jy); setJm(todayParts.jm); setOpen(false); }}
          >
            امروز
          </Button>
          {clearable && value && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="h-7 text-xs text-destructive"
              onClick={() => { onChange(null); setOpen(false); }}
            >
              <X className="h-3 w-3 ml-1" /> پاک کردن
            </Button>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

/** نمایش ساده تاریخ شمسی با پشتیبانی null */
export function JalaliText({ value, className }: { value?: string | null; className?: string }) {
  if (!value) return <span className={cn("text-muted-foreground", className)}>—</span>;
  return <span className={className}>{formatJalali(value)}</span>;
}

export { parseDateStr };
