"use client";

import { TaskT, IssueT, CommentT } from "./types";
import { computeTask, LIGHT_COLORS } from "@/lib/status";
import { faNum, formatJalali } from "@/lib/jalali";
import { LightBadge } from "./StatusLight";
import { Check, PauseCircle } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * پایپ‌لاین افقی: هر تسک یک ایستگاه با ددلاین و چراغ خودش.
 * فلش «الان اینجا» روی اولین کارِ در جریان، و نقطه قرمز روی محل توقف (blocked).
 */
export function Pipeline({
  tasks,
  issues,
  comments,
  warningDays,
  onSelectTask,
  exportId,
}: {
  tasks: TaskT[];
  issues: IssueT[];
  comments: CommentT[];
  warningDays: number;
  onSelectTask?: (taskId: string) => void;
  exportId?: string;
}) {
  if (!tasks.length) {
    return (
      <div className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
        هنوز کاری برای این پروژه تعریف نشده — با دکمه «افزودن کار» شروع کنید
      </div>
    );
  }

  const computed = tasks.map((t) => ({ task: t, c: computeTask(t, issues, comments, warningDays) }));
  const currentIdx = computed.findIndex((x) => x.task.status === "in_progress");
  const fallbackIdx = computed.findIndex((x) => x.task.status === "todo");
  const currentPos = currentIdx >= 0 ? currentIdx : fallbackIdx;
  const doneCount = tasks.filter((t) => t.status === "done").length;
  const pct = Math.round((doneCount / tasks.length) * 100);

  return (
    <div id={exportId} className="relative rounded-xl border bg-card p-5 pt-6">
      {/* نوار پیشرفت کل */}
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="text-xs font-semibold text-muted-foreground">
          مسیر پروژه — {faNum(doneCount)} از {faNum(tasks.length)} کار انجام شده ({faNum(pct)}٪)
        </div>
      </div>

      <div className="overflow-x-auto custom-scrollbar pb-2">
        <div className="relative min-w-max flex items-start px-11">
          {/* خط تایم‌لاین */}
          <div className="absolute top-[22px] left-[44px] right-[44px] h-1.5 bg-slate-200 rounded-full" />
          <div
            className="absolute top-[22px] h-1.5 rounded-full bg-gradient-to-l from-teal-600 to-teal-400 transition-all duration-500"
            style={{ insetInlineStart: 0, width: `calc((100% - 88px) * ${doneCount / Math.max(1, tasks.length)})` }}
          />

          {computed.map(({ task, c }, i) => {
            const isCurrent = i === currentPos;
            const isBlocked = task.status === "blocked";
            const isDone = task.status === "done";
            return (
              <div key={task.id} className="relative flex flex-col items-center w-32 shrink-0 -mx-1">
                {/* دایره ایستگاه */}
                <button
                  type="button"
                  onClick={() => onSelectTask?.(task.id)}
                  title={`${task.title} — ${c.label}${isBlocked ? " — " + (c.blockedReason ?? "") : ""}`}
                  className={cn(
                    "relative z-10 h-11 w-11 rounded-full flex items-center justify-center text-white font-bold shadow-md transition-transform hover:scale-105 focus:outline-none",
                    isCurrent && "current-position ring-4 ring-teal-500/40",
                    isBlocked && "ring-4 ring-red-500/40"
                  )}
                  style={{ backgroundColor: LIGHT_COLORS[c.light] }}
                >
                  {isDone ? <Check className="h-5 w-5" /> : isBlocked ? <PauseCircle className="h-5 w-5" /> : faNum(task.order)}
                </button>

                {/* برچسب موقعیت فعلی */}
                <div className="h-5 mt-1">
                  {isCurrent && !isDone && (
                    <span className="text-[10px] font-bold text-teal-700 bg-teal-50 border border-teal-200 rounded-full px-2 py-0.5">
                      الان اینجا
                    </span>
                  )}
                  {isBlocked && (
                    <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-200 rounded-full px-2 py-0.5">
                      توقف
                    </span>
                  )}
                </div>

                {/* عنوان و تاریخ */}
                <div className="mt-0.5 w-32 text-center">
                  <p className="text-xs font-semibold leading-4 line-clamp-2 h-8" title={task.title}>{task.title}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    ددلاین: {formatJalali(c.effectiveDeadline)}
                  </p>
                  <div className="mt-1 flex justify-center">
                    <LightBadge light={c.light} label={c.label} />
                  </div>
                  {c.openIssues.length > 0 && (
                    <p className="text-[10px] text-red-600 font-semibold mt-1" title={c.openIssues.map((i) => i.title).join("؛ ")}>
                      {c.openIssues.length === 1 ? "۱ مشکل باز" : `${faNum(c.openIssues.length)} مشکل باز`}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
