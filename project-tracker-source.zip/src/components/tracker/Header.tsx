"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { api } from "./api";
import { User } from "./types";
import { LayoutDashboard, LogOut, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

export type TopTab = "dashboard" | "settings";

export function Header({
  user,
  tab,
  onTab,
  onLogout,
}: {
  user: User;
  tab: TopTab;
  onTab: (t: TopTab) => void;
  onLogout: () => void;
}) {
  return (
    <header className="sticky top-0 z-40 bg-neutral-950 text-white shadow-lg no-print">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-3">
        <img src="/irancell-logo.png" alt="ایرانسل" className="h-11 object-contain rounded-lg" />
        <div className="min-w-0">
          <h1 className="font-bold text-base leading-tight truncate">سامانه ردیابی پروژه‌ها</h1>
          <p className="text-[11px] text-white/60 leading-tight">پایپ‌لاین · ددلاین · دیلی · خروجی داشبورد</p>
        </div>

        <nav className="mr-auto flex items-center gap-1.5">
          <Button
            variant={tab === "dashboard" ? "secondary" : "ghost"}
            size="sm"
            onClick={() => onTab("dashboard")}
            className={cn("gap-1.5 text-white", tab === "dashboard" ? "bg-white text-neutral-900 hover:bg-white/90" : "hover:bg-white/10")}
          >
            <LayoutDashboard className="h-4 w-4" />
            <span className="hidden sm:inline">داشبورد</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onTab("settings")}
            className={cn("gap-1.5 text-white", tab === "settings" ? "bg-white text-neutral-900 hover:bg-white/90" : "hover:bg-white/10")}
          >
            <Settings className="h-4 w-4" />
            <span className="hidden sm:inline">تنظیمات</span>
          </Button>

          <div className="h-6 w-px bg-white/20 mx-1" />

          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold hidden sm:inline">{user.name}</span>
            <Badge variant="outline" className="border-white/30 text-white/80 text-[10px]">
              {user.role === "admin" ? "مدیر" : "عضو تیم"}
            </Badge>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-white hover:bg-white/10" onClick={onLogout} title="خروج">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
}
