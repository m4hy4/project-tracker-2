// تایپ‌های مشترک کلاینت
export interface User {
  id: string;
  username: string;
  name: string;
  role: string;
}

export interface Service {
  id: string;
  name: string;
  description: string;
  capabilities: string[];
  color: string;
  icon: string;
  order: number;
  _count?: { projects: number };
}

export interface CommentT {
  id: string;
  taskId?: string | null;
  projectId?: string | null;
  authorName: string;
  body: string;
  createdAt: string;
}

export interface IssueT {
  id: string;
  taskId?: string | null;
  projectId?: string | null;
  title: string;
  description: string;
  occurredAt: string;
  estimatedResolveAt: string;
  resolvedAt?: string | null;
  createdBy: string;
}

export interface TaskT {
  id: string;
  projectId: string;
  title: string;
  description: string;
  order: number;
  status: string;
  progress: number;
  startDate?: string | null;
  dueDate?: string | null;
  assignee: string;
  comments: CommentT[];
  issues: IssueT[];
}

export interface ProjectT {
  id: string;
  name: string;
  serviceId: string;
  service: Service;
  description: string;
  location: string;
  ownerName: string;
  status: string;
  startDate?: string | null;
  dueDate?: string | null;
  createdAt: string;
  tasks: TaskT[];
  issues: IssueT[];
  comments: CommentT[];
}

export interface Settings {
  warningDays: number;
}
