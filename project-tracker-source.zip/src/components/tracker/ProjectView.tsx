"use client";

import { useMemo, useState } from "react";
import { ProjectT, Settings, User } from "./types";
import { computeProject, PROJECT_STATUSES } from "@/lib/status";
import { faNum, formatJalali } from "@/lib/jalali";
import { LightBadge } from "./StatusLight";
import { JalaliDatePicker } from "./JalaliDatePicker";
import { Pipeline } from "./Pipeline";
import { TaskTable, IssueChip, IssueDialog } from "./TaskTable";
import { ExportMenu } from "./ExportMenu";
import { api } from "./api";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import {
  ArrowRight, CalendarDays, Info, MapPin, Pencil, Send, Trash2, User as UserIcon, Wrench,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function ProjectView({
  project, settings, user, users, onBack, onChanged, onEditProject, onPrint,
}: {
  project: ProjectT;
  settings: Settings;
  user: User;
  users: User[];
  onBack: () => void;
  onChanged: () => void;
  onEditProject: () => void;
  onPrint: () => void;
}) {
  const { toast } = useToast();
  const [issueForProject, setIssueForProject] = useState(false);
  const [commentDraft, setCommentDraft] = useState("");

  const computed = useMemo(
    () => computeProject(project, project.tasks, project.issues, project.comments, settings.warningDays),
    [project, settings.warningDays]
  );
  const progress = useMemo(
    () => (project.tasks.length ? Math.round(project.tasks.reduce((a, t) => a + t.progress, 0) / project.tasks.length) : 0),
    [project.tasks]
  );
  const openProjectIssues = project.issues.filter((i) => !i.taskId && !i.resolvedAt);
  const allProjectIssues = project.issues.filter((i) => !i.taskId);
  const members = useMemo(() => {
    const set = new Set(users.map((u) => u.name));
    project.tasks.forEach((t) => t.assignee && set.add(t.assignee));
    return Array.from(set);
  }, [users, project.tasks]);

  async function addProjectComment() {
    const body = commentDraft.trim();
    if (!body) return;
    try {
      await api.createComment({ projectId: project.id, body });
      setCommentDraft("");
      toast({ title: "کامنت پروژه ثبت شد" });
      onChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  async function changeStatus(status: string) {
    try {
      await api.updateProject(project.id, { status });
      toast({ title: "وضعیت پروژه بروز شد" });
      onChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  async function setProjectDue(v: string | null) {
    try {
      await api.updateProject(project.id, { dueDate: v });
      toast({ title: "ددلاین پروژه بروز شد" });
      onChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" });
    }
  }

  return (
    <div className="space-y-5">
      {/* هدر پروژه */}
      <div className="rounded-xl border bg-neutral-950 text-white p-4">
        <div className="flex items-start gap-3 flex-wrap">
          <Button variant="ghost" size="sm" onClick={onBack} className="gap-1 text-white hover:bg-white/10 shrink-0">
            <ArrowRight className="h-4 w-4" /> بازگشت
          </Button>
          <div className="min-w-0 flex-1">
            <h2 className="text-lg font-bold leading-6">{project.name}</h2>
            <p className="text-xs text-white/60 mt-0.5 flex items-center gap-3 flex-wrap">
              <span className="inline-flex items-center gap-1">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: project.service.color }} />
                {project.service.name}
              </span>
              {project.location && <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{project.location}</span>}
              {project.ownerName && <span className="inline-flex items-center gap-1"><UserIcon className="h-3 w-3" />{project.ownerName}</span>}
              <span className="inline-flex items-center gap-1"><CalendarDays className="h-3 w-3" />شروع: {formatJalali(project.startDate)}</span>
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <ExportMenu
              pngItems={[
                { id: "export-pipeline", label: "PNG — پایپ‌لاین و موقعیت پروژه", filename: `${project.name}-pipeline.png` },
                { id: "export-service-box", label: "PNG — باکس سرویس و قابلیت‌ها", filename: `${project.name}-service.png` },
                { id: "export-tasks-table", label: "PNG — جدول کارها", filename: `${project.name}-tasks.png` },
              ]}
              onPrint={onPrint}
            />
            <Button variant="secondary" size="sm" onClick={onEditProject} className="gap-1.5">
              <Pencil className="h-3.5 w-3.5" /> ویرایش پروژه
            </Button>
          </div>
        </div>

        {/* نوار وضعیت */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4">
          <div className="rounded-lg bg-white/10 p-2.5 text-center">
            <p className="text-[10px] text-white/60 mb-1">چراغ وضعیت</p>
            <span className="bg-white rounded-full px-2 inline-block">
              <LightBadge light={computed.light} label={computed.label} className="text-[11px]" />
            </span>
          </div>
          <div className="rounded-lg bg-white/10 p-2.5 text-center">
            <p className="text-[10px] text-white/60 mb-1">پیشرفت کل</p>
            <div className="flex items-center gap-2 px-2">
              <Progress value={progress} className="h-2 flex-1 bg-white/20" />
              <span className="text-sm font-bold">{faNum(progress)}٪</span>
            </div>
          </div>
          <div className="rounded-lg bg-white/10 p-2.5 text-center">
            <p className="text-[10px] text-white/60 mb-1">کارها (انجام/کل)</p>
            <p className="text-sm font-bold">
              {faNum(project.tasks.filter((t) => t.status === "done").length)} / {faNum(project.tasks.length)}
            </p>
          </div>
          <div className="rounded-lg bg-white/10 p-2.5 text-center">
            <p className="text-[10px] text-white/60 mb-1">دیلی پروژه</p>
            <p className={`text-sm font-bold ${computed.delayDays > 0 ? "text-red-400" : "text-emerald-400"}`}>
              {faNum(computed.delayDays)} روز
            </p>
          </div>
          <div className="rounded-lg bg-white/10 p-2.5 text-center">
            <p className="text-[10px] text-white/60 mb-1">وضعیت + ددلاین کل</p>
            <div className="flex items-center justify-center gap-1.5 flex-wrap">
              <Select value={project.status} onValueChange={changeStatus}>
                <SelectTrigger className="h-7 text-[11px] w-28 bg-white/90 text-neutral-900 border-none">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PROJECT_STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <JalaliDatePicker value={project.dueDate} onChange={setProjectDue} className="h-7 text-[11px] bg-white/90" clearable={false} />
            </div>
          </div>
        </div>
      </div>

      {/* باکس سرویس: توضیحات + قابلیت‌ها */}
      <Card id="export-service-box">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: `${project.service.color}1a`, color: project.service.color }}>
              <Info className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-bold text-sm">سرویس: {project.service.name}</h3>
                <span className="text-[10px] bg-muted rounded px-1.5 py-0.5">باکس توضیحات و قابلیت‌ها</span>
              </div>
              <p className="text-xs text-muted-foreground leading-5 mt-1.5">{project.service.description || "برای این سرویس توضیحاتی ثبت نشده"}</p>
              {project.service.capabilities.length > 0 && (
                <div className="mt-2.5">
                  <p className="text-[11px] font-bold text-muted-foreground mb-1.5">قابلیت‌های این سرویس:</p>
                  <div className="grid sm:grid-cols-2 gap-1.5">
                    {project.service.capabilities.map((c) => (
                      <div key={c} className="flex items-start gap-1.5 text-xs bg-accent rounded-md px-2.5 py-1.5">
                        <span className="mt-1 h-1.5 w-1.5 rounded-full shrink-0" style={{ backgroundColor: project.service.color }} />
                        {c}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {project.description && (
                <p className="text-xs leading-5 mt-3 pt-2.5 border-t"><b>توضیحات پروژه:</b> {project.description}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* پایپ‌لاین */}
      <Pipeline
        exportId="export-pipeline"
        tasks={project.tasks}
        issues={project.issues}
        comments={project.comments}
        warningDays={settings.warningDays}
      />

      {/* جدول کارها */}
      <div id="export-tasks-table">
        <TaskTable
          tasks={project.tasks}
          issues={project.issues}
          comments={project.comments}
          warningDays={settings.warningDays}
          userName={user.name}
          members={members}
          onChanged={onChanged}
        />
      </div>

      {/* مشکلات پروژه + کامنت‌های پروژه */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold flex items-center gap-1.5">
                <Wrench className="h-4 w-4 text-orange-600" /> مشکلات کل پروژه ({faNum(allProjectIssues.length)})
              </h3>
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => setIssueForProject(true)}>
                ثبت مشکل پروژه
              </Button>
            </div>
            {allProjectIssues.length === 0 && (
              <p className="text-xs text-muted-foreground">مشکلی در سطح پروژه ثبت نشده — مشکلات هر کار داخل جدول کارها ثبت می‌شود</p>
            )}
            <div className="space-y-2 max-h-72 overflow-y-auto custom-scrollbar">
              {allProjectIssues.map((i) => <IssueChip key={i.id} issue={i} onChanged={onChanged} />)}
            </div>
            {openProjectIssues.length > 0 && (
              <p className="text-[11px] rounded-md bg-orange-50 border border-orange-200 text-orange-800 px-2.5 py-1.5">
                ⚠ {faNum(openProjectIssues.length)} مشکل باز در سطح پروژه — تا پیش‌بینی رفع آن‌ها، ددلاین مؤثر پروژه جابه‌جا می‌شود.
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 space-y-3">
            <h3 className="text-sm font-bold">کامنت‌های پروژه ({faNum(project.comments.length)})</h3>
            <div className="space-y-1.5 max-h-56 overflow-y-auto custom-scrollbar">
              {project.comments.length === 0 && <p className="text-xs text-muted-foreground">اولین کامنت پروژه را ثبت کنید</p>}
              {project.comments.map((c) => (
                <div key={c.id} className="rounded-lg border bg-card px-3 py-2 flex items-start gap-2 group">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs leading-5 whitespace-pre-wrap">{c.body}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{c.authorName} · {formatJalali(c.createdAt.slice(0, 10))}</p>
                  </div>
                  <Button
                    variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100 text-muted-foreground"
                    title="حذف"
                    onClick={async () => {
                      try { await api.deleteComment(c.id); toast({ title: "کامنت حذف شد" }); onChanged(); }
                      catch (e) { toast({ title: "خطا", description: e instanceof Error ? e.message : String(e), variant: "destructive" }); }
                    }}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                value={commentDraft}
                onChange={(e) => setCommentDraft(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); addProjectComment(); } }}
                placeholder={`کامنت به نام ${user.name}`}
                className="h-9 text-xs"
              />
              <Button size="icon" className="h-9 w-9 shrink-0" onClick={addProjectComment} disabled={!commentDraft.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* دیالوگ مشکل پروژه */}
      {issueForProject && (
        <IssueDialog projectId={project.id} onClose={() => setIssueForProject(false)} onCreated={() => { setIssueForProject(false); onChanged(); }} />
      )}

    </div>
  );
}
